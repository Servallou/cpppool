/*
** EPITECH PROJECT, 2021
** day 02 exo 01
** File description:
** day 02 exo 01
*/

#include "mem_ptr.h"
#include <string.h>
#include <stdlib.h>

void add_str(const char *str1, const char *str2, char **res)
{
    res[0] = malloc(strlen(str1) + strlen(str2) * sizeof(char *));
    res[0] = strcat(res[0], str1);
    res[0] = strcat(res[0], str2);
}

void add_str_struct(str_op_t *str_op)
{
    int nb = strlen(str_op->str1) + strlen(str_op->str2);

    str_op->res = malloc(sizeof(char *) * nb);
    str_op->res = strcat(str_op->res ,str_op->str1);
    str_op->res = strcat(str_op->res ,str_op->str2);
}
