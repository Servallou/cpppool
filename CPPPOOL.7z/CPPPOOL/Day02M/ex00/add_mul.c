/*
** EPITECH PROJECT, 2021
** day 02 ex 00
** File description:
** day 02 ex 00
*/

void add_mul_4param(int first, int second, int *sum, int *product)
{
    sum[0] = first + second;
    product[0] = first * second;
}

void add_mul_2param(int *first, int *second)
{
    int temp = first[0];

    first[0] = temp + second[0];
    second[0] = temp * second[0];
}
