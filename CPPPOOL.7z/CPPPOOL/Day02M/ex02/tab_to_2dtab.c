/*
** EPITECH PROJECT, 2021
** day 02 exo 2
** File description:
** day 02 exo 2
*/

#include <stdlib.h>

void tab_to_2dtab(const int *tab, int lenght, int width, int ***res)
{
    int k = 0;

    *res = malloc(sizeof(int *) * lenght);
    for (int i = 0; i != lenght; i++) {
        (*res)[i] = malloc(sizeof(int) * width);
        for (int j = 0; j != width; j++, k++)
            (*res)[i][j] = tab[k];
    }
}
