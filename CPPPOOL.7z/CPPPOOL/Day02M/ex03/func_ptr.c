/*
** EPITECH PROJECT, 2021
** day 2 exo 3
** File description:
** day 02 exo 3
*/

#include "func_ptr.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void print_normal(const char *str)
{
    printf("%s\n", str);
}

void print_reverse(const char *str)
{
    char c;
    int i = strlen(str);
    int j = 0;
    char *str1 = malloc(sizeof(char) * i);

    str1 = strcpy(str1, str);
    for (i--; i >= 0; i--)
        str1[j++] = str[i];
    str1[i] = '\0';
    printf("%s\n", str1);
    free(str1);
}

void print_upper(const char *str)
{
    char *str1 = malloc(sizeof(char) * strlen(str));

    str1 = strcpy(str1, str);
    for (int i = 0; str1[i] != '\0'; i++)
        if (islower(str1[i]))
            str1[i] = str1[i] - 32;
    printf("%s\n", str1);
    free(str1);
}

void print_42(const char *str)
{
    printf("42\n");
}

void do_action(action_t action, const char *str)
{
    action_func_t list[] = {
        {PRINT_NORMAL, &print_normal},
        {PRINT_REVERSE, &print_reverse},
        {PRINT_UPPER, &print_upper},
        {PRINT_42, &print_42},
    };

    for (int i = 0; i != 4; i++)
        if (action == list[i].action)
            (*list[i].func)(str);
}
