/*
** EPITECH PROJECT, 2021
** day 02 exo 3
** File description:
** day 02 exo 3
*/

#ifndef _FUNC_PTR_
#define _FUNC_PTR_

#include "func_ptr_enum.h"

typedef void (*func_t)(const char *str);

typedef struct s_action_func {
    action_t action;
    func_t func;
} action_func_t;

#endif
