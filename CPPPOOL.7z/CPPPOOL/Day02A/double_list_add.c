/*
** EPITECH PROJECT, 2021
** ex 00 day 2 bis
** File description:
** ex 00 day 2 bis
*/

#include "double_list.h"
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

bool double_list_add_elem_at_front(double_list_t *front_ptr, double elem)
{
    double_list_t list = malloc(sizeof(double_list_t));

    if (double_list_is_empty(list) == true)
        return (false);
    list->value = elem;
    list->next = (*front_ptr);
    (*front_ptr) = list;
    return (true);
}

bool double_list_add_elem_at_back(double_list_t *front_ptr, double elem)
{
    double_list_t list = malloc(sizeof(double_list_t));
    double_list_t current = *front_ptr;

    if (double_list_is_empty(list) == true)
        return (false);
    list->value = elem;
    list->next = NULL;
    if (double_list_is_empty(*front_ptr) == true) {
        *front_ptr = list;
        return (true);
    }
    if (current->next != NULL)
        while (current->next != NULL)
            current = current->next;
    current->next = list;
    return (true);
}

bool double_list_add_elem_at_position(double_list_t *front_ptr, double elem,
                                      unsigned int position)
{
    double_list_t list;
    double_list_t list_temp = *front_ptr;

    if (position == 0)
        return (double_list_add_elem_at_front(front_ptr, elem));
    if (position == double_list_get_size(list_temp))
        return (double_list_add_elem_at_back(front_ptr, elem));
    list = malloc(sizeof(double_list_t));
    if (double_list_is_empty(list) == true)
        return (false);
    list->value = elem;
    for (int i = 0; i != position - 1; i++, list_temp = list_temp->next);
    list->next = list_temp->next;
    for (int i = 0; i != position - 2; i++, *front_ptr = (*front_ptr)->next);
    (*front_ptr)->next = list;
    return (true);
}
