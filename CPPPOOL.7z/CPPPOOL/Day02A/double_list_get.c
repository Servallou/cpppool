/*
** EPITECH PROJECT, 2021
** day 02 ex 00
** File description:
** day 02 ex 00
*/

#include "double_list.h"
#include <stddef.h>
#include <stdlib.h>

double   double_list_get_elem_at_front(double_list_t list)
{
    if (double_list_is_empty(list) == true)
        return (0);
    return (list->value);
}

double   double_list_get_elem_at_back(double_list_t list)
{
    if (double_list_is_empty(list) == true)
        return (0);
    for (; list->next != NULL; list = list->next);
    return (list->value);
}

double   double_list_get_elem_at_position(double_list_t list,
                                          unsigned int position)
{
    int nb;

    if (position == 0)
        return (double_list_get_elem_at_front(list));
    nb = double_list_get_size(list);
    if (double_list_is_empty(list) == true || nb < position)
        return (0);
    if (nb == position)
        return (double_list_get_elem_at_back(list));
    for (int i = 0; i != position; i++, list = list->next);
    return (list->value);
}
