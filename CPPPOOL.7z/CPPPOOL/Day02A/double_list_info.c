/*
** EPITECH PROJECT, 2021
** day 02 exo 00
** File description:
** day 02 exo 00
*/

#include "double_list.h"
#include <stdio.h>

unsigned int double_list_get_size(double_list_t list)
{
    int i = 1;

    if (list->next == NULL)
        return (i);
    for (; list->next != NULL; i++)
        list = list->next;
    return (i);
}

bool double_list_is_empty(double_list_t list)
{
    if (list == NULL)
        return (true);
    else
        return (false);
}

void double_list_dump(double_list_t list)
{
    while (list != NULL) {
        printf("%f\n", list->value);
        list = list->next;
    }
}

doublelist_node_t *double_list_get_first_node_with_value(double_list_t list,
    double value)
{
    if (double_list_is_empty(list) == true)
        return (NULL);
    for (; list->next != NULL; list = list->next)
        if (list->value == value)
            return (list);
    return (NULL);
}
