/*
** EPITECH PROJECT, 2021
** main 
** File description:
** main
*/

#include "double_list.h"
#include <stdio.h>

static void populate_list(double_list_t *list_head)
{

    if (double_list_is_empty((*list_head)))
        printf("the list is empty\n");
    else
        printf("the list is NOT empty\n");
    double_list_add_elem_at_back(list_head , 5.2);
    double_list_add_elem_at_back(list_head , 42.5);
    double_list_add_elem_at_back(list_head , 3.3);
    double_list_add_elem_at_back(list_head , 8888.3);
    if (double_list_is_empty((*list_head)))
        printf("the list is empty\n");
    else
        printf("the list is NOT empty\n");

    double_list_add_elem_at_front(list_head , 5.2);
    double_list_add_elem_at_front(list_head , 42.5);
    double_list_add_elem_at_front(list_head , 3.3);
    double_list_add_elem_at_front(list_head , 8888.3);

    printf("before del\n");
    double_list_dump((*list_head));
    printf("after del\n");
    //double_list_del_elem_at_front(list_head);
    double_list_del_elem_at_position(list_head, 4);
    double_list_del_elem_at_position(list_head, 10);
    double_list_del_elem_at_position(list_head, 0);
    double_list_del_elem_at_position(list_head, 1);
    //double_list_del_elem_at_back(list_head);
    double_list_dump((*list_head));
    printf("\nafter add pos 2 4 and 0\n");
    double_list_add_elem_at_position(list_head, 666, 2);
    double_list_add_elem_at_position(list_head, 777, 4);
    double_list_add_elem_at_position(list_head, 444, 1);
    double_list_dump((*list_head));
}

static void test_size(double_list_t list_head)
{
    //    double_list_dump(list_head);
    printf("There are %u elements in the list\n", double_list_get_size(list_head));
    printf("This is the first value of the list : %f\n",
           double_list_get_elem_at_front(list_head));
    printf("This is the last value of the list : %f\n",
           double_list_get_elem_at_back(list_head));
    printf("This is the %d of the list : %f\n", 2,
           double_list_get_elem_at_position(list_head, 2));
    printf("This is the %d of the list : %f\n", 4,
           double_list_get_elem_at_position(list_head, 4));
    printf("This is the %d of the list : %f\n", 0,
           double_list_get_elem_at_position(list_head, 0));

    printf("\n\ntest first node with value\n");

    double_list_t node = double_list_get_first_node_with_value(list_head, 5.2);

    if (node != NULL)
        printf("there is a node with the %f value\n", node->value);
    else
        printf("there is no node with this value\n");
    node = double_list_get_first_node_with_value(list_head, 5.0);
    if (node != NULL)
        printf("there is a node with the %f value\n", node->value);
    else
        printf("there is no node with this value\n");

}

static void test_del(double_list_t *list_head)
{
    double_list_del_elem_at_back(list_head);
    printf("There  are %u elements  in the  list\n", double_list_get_size (* list_head));
    double_list_dump (* list_head);
}

int main(void)
{
    double_list_t list_head = NULL;

    populate_list(&list_head);
    test_size(list_head);
    //    test_del(&list_head);
    return  0;
}
