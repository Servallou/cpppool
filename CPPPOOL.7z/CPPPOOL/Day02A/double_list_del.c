/*
** EPITECH PROJECT, 2021
** day 02 ex 00
** File description:
** day 02 ex 00
*/

#include "double_list.h"
#include <stdio.h>
#include <stdlib.h>

bool double_list_del_elem_at_front(double_list_t *front_ptr)
{
    if (double_list_is_empty(*front_ptr) == true)
        return (false);
    *front_ptr = (*front_ptr)->next;
    return (true);
}

bool double_list_del_elem_at_back(double_list_t *front_ptr)
{
    double_list_t current = *front_ptr;
    int nb;

    if (double_list_is_empty(*front_ptr) == true)
        return (false);
    nb = double_list_get_size(*front_ptr);
    for (int i = 0; i != nb - 2; i++, current = current->next);
    current->next = NULL;
    return (true);
}

bool double_list_del_elem_at_position(double_list_t *front_ptr,
    unsigned int position)
{
    int nb;
    double_list_t list;
    double_list_t current = *front_ptr;

    if (position == 0)
        return (double_list_del_elem_at_front(front_ptr));
    nb = double_list_get_size(current);
    if (position == nb)
        return (double_list_del_elem_at_back(front_ptr));
    list = malloc(sizeof(double_list_t));
    if (double_list_is_empty(list) == true || nb < position)
        return (false);
    for (int i = 0; i != nb - 1; i++, current = current->next);
    list->next = list->next->next;
    (*front_ptr)->next = list;
    return (true);
}
