#include "ex02.hpp"

int main ()
{
    int tab[2] = {3, 0};
    int minium = templateMin(tab, 2);
    std::cout << "templateMin(tab, 2) = " << minium << std::endl;
    minium = nonTemplateMin(tab, 2);
    std::cout << "nonTemplateMin(tab, 2) = " << minium << std::endl;
}