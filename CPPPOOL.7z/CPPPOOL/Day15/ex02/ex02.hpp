/*
** EPITECH PROJECT, 2021
** day 15 ex02
** File description:
** day 15 ex02
*/

#ifndef EX02
#define EX02

#include <iostream>

template <typename type>
const type &min(type const &a, type const &b) {
    std::cout << "template min" << std::endl;
    if (a < b)
        return a;
    else if (a > b)
        return b;
    else
        return a;
}

int min (int a, int b) {
    std::cout << "non-template min" << std::endl;
    if (a < b)
        return a;
    else if (a > b)
        return b;
    else
        return a;
}

template <typename type, typename type1>
const type &templateMin (type const *array, type1 const size) {
    type &value = const_cast<type&>(array[0]);
    for (int i = 1; i != size; i++)
        value = min<type>(value, array[i]);
    return value;
}

int nonTemplateMin(int *array, int size) {
    int value = array[0];
    for (int i = 1; i != size; i++)
        value = min(value, array[i]);
    return value;
}

#endif