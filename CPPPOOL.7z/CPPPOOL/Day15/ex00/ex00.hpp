/*
** EPITECH PROJECT, 2021
** day 15 ex00
** File description:
** day 15 ex00
*/

#ifndef EX00
#define EX00

template <typename type>
void swap(type &a, type &b) {
    type c = a;

    a = b;
    b = c;
}

template <typename type>
type min(type a, type b) {
    if (a < b)
        return a;
    else if (a > b)
        return b;
    else
        return b;
}

template <typename type>
type max(type a, type b) {
    if (a > b)
        return a;
    else if (a < b)
        return b;
    else
        return b;
}

template <typename type>
type add (type a, type b) {
    return a + b;
}

#endif