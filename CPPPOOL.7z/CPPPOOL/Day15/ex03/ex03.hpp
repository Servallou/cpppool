/*
** EPITECH PROJECT, 2021
** day 15 ex03
** File description:
** day 15 ex03
*/

#ifndef EX03
#define EX03

#include <iostream>

template <typename type>
void foreach(type const *array, void(func)(type const &), int size) {
    for (int i = 0; i != size; i++)
        (func)(array[i]);
}

template <typename type>
void print(type const &printable) {
    std::cout << printable << std::endl;
}

#endif