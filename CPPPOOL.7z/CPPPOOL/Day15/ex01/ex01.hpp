/*
** EPITECH PROJECT, 2021
** day 15 ex00
** File description:
** day 15 ex00
*/

#ifndef EX01
#define EX01

#include "cstring"

template <typename type>
int compare(type const &t1, type const &t2) {
    int res = 0;

    if (t1 == t2)
        res = 0;
    if (t1 < t2)
        res = -1;
    if (t1 > t2)
        res = 1;
    return res;
}

template <>
int compare<const char *>(const char * const &a, const char *const &b) {
    int res = strcmp(a, b);

    if (res < 0)
        return -1;
    else if (res > 0)
        return 1;
    else
        return 0;
}

#endif