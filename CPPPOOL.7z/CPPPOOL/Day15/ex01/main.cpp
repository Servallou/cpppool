#include "ex01.hpp"
#include <iostream>

class toto
{
public :
    toto() = default;
    toto& operator=(const toto &) = delete;
    toto(const toto &) = delete;

    bool operator==(const toto &) const { return true ; }
    bool operator>(const toto &) const { return false ; }
    bool operator<(const toto &) const { return false ; }
};

int main(void)
{
    toto a, b;
    const char *s1 = "42";
    const char *s2 = "lulz";

    std::cout << compare(a, b) << std::endl;
    std::cout << compare(1, 2) << std::endl;
    std::cout << compare<const char *>("chaineZ", "chaineA42") << std::endl;
    std::cout << compare(s1, s2) << std::endl;
}