/*
** EPITECH PROJECT, 2021
** day 15 ex04
** File description:
** day 15 ex04
*/

#include <iostream>

#ifndef EX04
#define EX04

template <typename type>
bool equal(const type &a, const type &b);

template <typename T>
class Tester {
    public :
        Tester();
        ~Tester();
        bool equal(const T &, const T &);
};

#endif