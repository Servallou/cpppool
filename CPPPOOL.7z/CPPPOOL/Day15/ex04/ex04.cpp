/*
** EPITECH PROJECT, 2021
** day 15 ex04
** File description:
** day 15 ex04
*/

#include "ex04.hpp"

template <>
Tester<int>::Tester() {}
template <>
Tester<int>::~Tester() {}

template <>
Tester<float>::Tester() {}
template <>
Tester<float>::~Tester() {}

template <>
Tester<double>::Tester() {}
template <>
Tester<double>::~Tester() {}

template <>
Tester<std::string>::Tester() {}
template <>
Tester<std::string>::~Tester() {}

template <>
bool Tester<int>::equal(const int &a, const int &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool equal<int>(const int &a, const int &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool Tester<float>::equal(const float &a, const float &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool equal<float>(const float &a, const float &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool Tester<double>::equal(const double &a, const double &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool equal<double>(const double &a, const double &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool Tester<std::string>::equal(const std::string &a, const std::string &b)
{
    if (a == b)
        return true;
    else
        return false;
}

template <>
bool equal<std::string>(const std::string &a, const std::string &b)
{
    if (a == b)
        return true;
    else
        return false;
}