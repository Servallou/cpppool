/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush1-mihailo.pavlovic
** File description:
** new
*/

#include "player.h"
#include "new.h"

Object *new(const Class *class, ...)
{
    Object *instance = NULL;

    va_list list;
    va_start(list, class);
    instance = va_new(class, &list);
    va_end(list);
    return instance;
}

Object *va_new(const Class *class, va_list *list)
{
    Object *instance = malloc(class->__size__);

    if (!instance || !memcpy(instance, class, class->__size__))
        raise("Malloc error");
    if (class->__ctor__) {
        class->__ctor__(instance, list);
    }
    return (instance);
}

void delete(Object *instance) {
    Class *class = (Class *)instance;

    if (!instance)
        raise("Delete can't free NULL");
    if (class->__dtor__) {
        class->__dtor__(instance);
    }
    free(instance);
}