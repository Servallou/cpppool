/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 02
*/

#define _GNU_SOURCE
#include "int.h"
#include "new.h"

typedef struct
{
    Class base;
    int data;
} IntClass;

static void int_ctor(IntClass *this, va_list *arg)
{
    if (!this)
        raise("Params must be allocated");
    this->data = va_arg(*arg, int);
}

IntClass *int_add(const IntClass *this, const IntClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Int, this->data + other->data);
}

IntClass *int_sub(const IntClass *this, const IntClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Int, this->data - other->data);
}

IntClass *int_mul(const IntClass *this, const IntClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    return new(Int, this->data * other->data);
}

IntClass *int_div(const IntClass *this, const IntClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    if (other->data == 0)
        raise("Can't divise by 0");
    return new(Int, this->data / other->data);
}


bool int_eq(const IntClass *this, const IntClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return this->data == other->data;
}

bool int_lt(const IntClass *this, const IntClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data < other->data);
}

bool int_gt(const IntClass *this, const IntClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data > other->data);
}

static char *to_string(IntClass *this)
{
    char *str = NULL;

    asprintf(&str, "<%s (%d)>", this->base.__name__, this->data);
    return str;
}

static const IntClass _description = {
    {
        .__size__ = sizeof(IntClass),
        .__name__ = "Int",
        .__ctor__ = (ctor_t)&int_ctor,
        .__dtor__ = NULL,
        .__str__ = (to_string_t)&to_string,
        .__add__ = (binary_operator_t)&int_add,
        .__sub__ = (binary_operator_t)&int_sub,
        .__mul__ = (binary_operator_t)&int_mul,
        .__div__ = (binary_operator_t)&int_div,
        .__eq__ = (binary_comparator_t)&int_eq,
        .__gt__ = (binary_comparator_t)&int_gt,
        .__lt__ = (binary_comparator_t)&int_lt
    },
    .data = 0
};

const Class *Int = (const Class *)&_description;