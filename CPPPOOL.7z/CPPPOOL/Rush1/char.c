/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 02
*/

#define _GNU_SOURCE
#include "char.h"
#include "new.h"

typedef struct
{
    Class base;
    char data;
} CharClass;

static void char_ctor(CharClass *this, va_list *arg)
{
    if (!this)
        raise("Params must be allocated");
    this->data = va_arg(*arg, int);
}

CharClass *char_add(const CharClass *this, const CharClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Char, this->data + other->data);
}

CharClass *char_sub(const CharClass *this, const CharClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Char, this->data - other->data);
}

CharClass *char_mul(const CharClass *this, const CharClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    return new(Char, this->data * other->data);
}

CharClass *char_div(const CharClass *this, const CharClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    if (other->data == 0)
        raise("Can't divise by 0");
    return new(Char, this->data / other->data);
}


bool char_eq(const CharClass *this, const CharClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return this->data == other->data;
}

bool char_lt(const CharClass *this, const CharClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data < other->data);
}

bool char_gt(const CharClass *this, const CharClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data > other->data);
}

static char *to_string(CharClass *this)
{
    char *str = NULL;

    asprintf(&str, "<%s (%c)>", this->base.__name__, this->data);
    return str;
}

static const CharClass _description = {
    {
        .__size__ = sizeof(CharClass),
        .__name__ = "Char",
        .__ctor__ = (ctor_t)&char_ctor,
        .__dtor__ = NULL,
        .__str__ = (to_string_t)&to_string,
        .__add__ = (binary_operator_t)&char_add,
        .__sub__ = (binary_operator_t)&char_sub,
        .__mul__ = (binary_operator_t)&char_mul,
        .__div__ = (binary_operator_t)&char_div,
        .__eq__ = (binary_comparator_t)&char_eq,
        .__gt__ = (binary_comparator_t)&char_gt,
        .__lt__ = (binary_comparator_t)&char_lt
    },
    .data = 0
};

const Class *Char = (const Class *)&_description;