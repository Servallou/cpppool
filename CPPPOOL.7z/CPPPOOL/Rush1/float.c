/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 02
*/

#define _GNU_SOURCE
#include "float.h"
#include "new.h"
#include <stdio.h>

typedef struct
{
    Class base;
    float data;
} FloatClass;

static void float_ctor(FloatClass *this, va_list *arg)
{
    if (!this)
        raise("Params must be allocated");
    this->data = va_arg(*arg, double);
}

FloatClass *float_add(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Float, this->data + other->data);
}

FloatClass *float_sub(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return new(Float, this->data - other->data);
}

FloatClass *float_mul(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    return new(Float, this->data * other->data);
}

FloatClass *float_div(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other) {
        raise("Params must be allocated");
    }
    if (other->data == 0)
        raise("Can't divise by 0");
    return new(Float, (float)this->data / (float)other->data);
}


bool float_eq(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return this->data == other->data;
}

bool float_lt(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data < other->data);
}

bool float_gt(const FloatClass *this, const FloatClass *other)
{
    if (!this || !other)
        raise("Params must be allocated");
    return (this->data > other->data);
}

static char *to_string(FloatClass *this)
{
    char *str = NULL;

    asprintf(&str, "<%s (%f)>", this->base.__name__, this->data);
    return str;
}

static const FloatClass _description = {
    {
        .__size__ = sizeof(FloatClass),
        .__name__ = "Float",
        .__ctor__ = (ctor_t)&float_ctor,
        .__dtor__ = NULL,
        .__str__ = (to_string_t)&to_string,
        .__add__ = (binary_operator_t)&float_add,
        .__sub__ = (binary_operator_t)&float_sub,
        .__mul__ = (binary_operator_t)&float_mul,
        .__div__ = (binary_operator_t)&float_div,
        .__eq__ = (binary_comparator_t)&float_eq,
        .__gt__ = (binary_comparator_t)&float_gt,
        .__lt__ = (binary_comparator_t)&float_lt
    },
    .data = 0
};

const Class *Float = (const Class *)&_description;