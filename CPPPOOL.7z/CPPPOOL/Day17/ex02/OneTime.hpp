/*
** EPITECH PROJECT, 2021
** day 17 ex02
** File description:
** day 17 ex02
*/