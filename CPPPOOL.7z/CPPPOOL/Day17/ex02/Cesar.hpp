/*
** EPITECH PROJECT, 2021
** day 17 ex02
** File description:
** day 17 ex02
*/

#ifndef CESAR_HPP
#define CESAR_HPP

#include "IEncryptionMethod.hpp"

class Cesar : public IEncryptionMethod
{
    public :
        void encryptChar(char plainchar);
        void decryptChar(char cipherchar);
        void reset();  
};

#endif