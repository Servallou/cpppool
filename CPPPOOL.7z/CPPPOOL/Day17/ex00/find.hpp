/*
** EPITECH PROJECT, 2021
** day 17 ex00
** File description:
** day 17 ex00
*/

#ifndef DOFIND_HPP
#define DOFIND_HPP

#include <algorithm>

template<typename T>
typename T::iterator do_find(T& tab, int nb)
{
    return std::find(tab.begin(), tab.end(), nb);
}

#endif