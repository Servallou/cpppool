/*
** EPITECH PROJECT, 2021
** day 08 ex 00 cpp
** File description:
** day 08 ex 00 cpp
*/

#include "Droid.hpp"

std::ostream& operator <<(std::ostream& out, Droid const &droid)
{
    out << "Droid '" << droid.getId() << "', " << *droid.getStatus() << ", " << droid.getEnergy();
    return (out);
}

Droid::Droid() : Id(""), Energy(50), Attack(25), Toughness(15), Status(new std::string("Standing by"))
{
    std::cout << "Droid '' Activated" << std::endl;
}

Droid::Droid(std::string id) : Energy(50), Attack(25), Toughness(15), Status(new std::string("Standing by"))
{
    this->Id = id;
    std::cout << "Droid '" << this->Id << "' Activated" << std::endl;
}

Droid::Droid(Droid const &droid) : Id(droid.getId()), Energy(droid.getEnergy()), Attack(25), Toughness(15), Status(new std::string(*droid.getStatus()))
{
    std::cout << "Droid '" << this->Id << "' Activated, Memory Dumped" << std::endl;
}

Droid::~Droid()
{
    std::cout << "Droid '" << this->Id << "' Destroyed" << std::endl;
}

Droid& Droid::operator<<(size_t &reload)
{
    size_t temp;

    if (this->Energy >= 100) {
        this->Energy = 100;
        return (*this);
    }
    if ((this->Energy + reload) > 100)
        temp = 100 - this->Energy;
    else
        temp = reload;
    this->Energy += temp;
    reload -= temp;
    return (*this);
}

Droid &Droid::operator=(Droid const &droid)
{
    if (this != &droid) {
        this->Id = droid.getId();
        this->Energy = droid.getEnergy();
        if (this->Status)
            delete this->Status;
        this->Status = new std::string(*droid.getStatus());
    }
    return (*this);
}

bool Droid::operator==(Droid const &droid) const
{
    if (this->Id == droid.getId() && this->Energy == droid.getEnergy()) {
        if (this->Status->compare(*droid.getStatus()) == 0)
            return (true);
        else
            return (false);        
    }
    else
        return (false);
}

bool Droid::operator!=(Droid const &droid) const
{
    if (this->Id == droid.getId() && this->Energy == droid.getEnergy()) {
        if (this->Status->compare(*droid.getStatus()) == 0)
            return (false);
        else
            return (true);
    }
    else
        return (true);
}

std::string Droid::getId() const
{
    return (this->Id);
}

void Droid::setId(std::string id)
{
    this-> Id = id;
}

size_t Droid::getEnergy() const
{
    return (this->Energy);
}

void Droid::setEnergy(size_t energy)
{
    if (energy <= 100)
        this->Energy = energy;
}

size_t Droid::getAttack() const
{
    return (this->Attack);
}

size_t Droid::getToughness() const
{
    return (this->Toughness);
}

std::string *Droid::getStatus() const
{
    return (this->Status);
}

void Droid::setStatus(std::string *status)
{
    this->Status = status;
}
