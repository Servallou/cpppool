/*
** EPITECH PROJECT, 2021
** Day 08 ex 01 cpp
** File description:
** day 08 ex 01 cpp
*/