/*
** EPITECH PROJECT, 2021
** Day 08 ex 00 cpp
** File description:
** day 08 ex 00 cpp
*/

#ifndef _DROID_
#define _DROID_

#include <iostream>
#include <string>

class Droid
{
private :
    std::string Id;
    size_t Energy;
    const size_t Attack;
    const size_t Toughness;
    std::string *Status;
public :
    Droid();
    Droid(std::string Id);
    Droid(Droid const &droid);
    ~Droid();
    std::string getId() const;
    size_t getEnergy() const;
    size_t getAttack() const;
    size_t getToughness() const;
    std::string *getStatus() const;
    void setId(std::string id);
    void setEnergy(size_t energy);
    void setStatus(std::string *status);
    Droid& operator=(Droid const &droid);
    Droid& operator<<(size_t &reload);
    bool operator==(Droid const &droid) const;
    bool operator!=(Droid const &droid) const;
};

std::ostream& operator <<(std::ostream& out, Droid const &droid);

#endif
