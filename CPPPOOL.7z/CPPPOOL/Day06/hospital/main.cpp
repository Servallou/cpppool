/*
** EPITECH PROJECT, 2021
** main
** File description:
** main
*/

#include <iostream>
#include "SickKoala.hpp"
#include "KoalaNurse.hpp"
#include "KoalaDoctor.hpp"

int main (void)
{
    std::string name = "Jean";
    SickKoala him(name);
    KoalaNurse her(65);
    KoalaDoctor doc("Mike");
    std::string test;
    bool lmao;

    him.poke();
    lmao = him.takeDrug("Kinder");
    if (lmao)
        std::cout << "good drug" << std::endl;
    lmao = him.takeDrug("AAAAAAAAAA");
    if (lmao)
        std::cout << "good drug" << std::endl;
    lmao = him.takeDrug("Mars");
    if (lmao)
        std::cout << "good drug" << std::endl;
    him.poke();
    him.overDrive("Kreog! how are you my Kreog! ?");
    std::cout << "\n\n";

    her.giveDrug("Kinder", &him);
    test = her.readReport("Jean.report");
    std::cout << "return str : " << test << std::endl;
    test = her.readReport("Jean.rfejfzoef");
    std::cout << "return str : " << test << std::endl;
    her.timeCheck();
    her.timeCheck();
    her.timeCheck();
    her.timeCheck();

    std::cout << "\n\n";
    doc.timeCheck();
    doc.diagnose(&him);
    her.readReport("Jean.report");
    doc.timeCheck();
    return (0);
}
