/*
** EPITECH PROJECT, 2021
** day 6 ex 3 cpp
** File description:
** day 6 ex 3 cpp
*/

#ifndef _KOALADOCTOR_
#define _KOALADOCTOR_

#include <string>
#include "SickKoala.hpp"

class KoalaDoctor
{
    std::string name;
    bool isWorking;

public :
    KoalaDoctor(std::string name);
    ~KoalaDoctor();
    void diagnose(SickKoala *SickKoala);
    void timeCheck();
};

#endif
