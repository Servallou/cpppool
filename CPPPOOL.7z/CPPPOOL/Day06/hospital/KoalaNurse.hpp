/*
** EPITECH PROJECT, 2021
** day 6 ex 3 cpp
** File description:
** day 6 ex 3 cpp
*/

#ifndef _KOALANURSE_
#define _KOALANURSE_

#include <string>
#include "SickKoala.hpp"

class KoalaNurse
{
    int id;
    bool isWorking;

public :
    KoalaNurse(int id);
    ~KoalaNurse();
    void giveDrug(std::string Drug, SickKoala *SickKoala);
    std::string readReport(std::string filename);
    void timeCheck();
};

#endif
