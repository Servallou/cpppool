/*
** EPITECH PROJECT, 2021
** day 6 ex 2 cpp
** File description:
** day 6 ex 2 cpp
*/

#include <iostream>
#include <fstream>
#include <string>
#include "KoalaNurse.hpp"
#include "SickKoala.hpp"

KoalaNurse::KoalaNurse(int id)
{
    this->id = id;
    this->isWorking = false;
}

KoalaNurse::~KoalaNurse()
{
    std::cout << "Nurse " << this->id << ": ";
    std::cout << "Finally some rest!" << std::endl;
}

void KoalaNurse::giveDrug(std::string Drug, SickKoala *SickKoala)
{
    if (SickKoala)
        SickKoala->takeDrug(Drug);
}

std::string KoalaNurse::readReport(std::string filename)
{
    std::ifstream file(filename);
    std::string drugname;
    size_t pos = 0;

    if (file || filename.find(".report", 0) == 0) {
        std::getline(file, drugname);
        while ((pos = filename.find(".", pos)) != std::string::npos)
            filename.replace(pos, 7, "\0");
        std::cout << "Nurse " << this->id << ": ";
        std::cout << "Kreog! Mr." << filename;
        std::cout << " needs a " << drugname << "!" << std::endl;
        return (drugname);
    }
    else
        return (drugname);
}

void KoalaNurse::timeCheck()
{
    if (this->isWorking == false) {
        this->isWorking = true;
        std::cout << "Nurse " << this->id << ": ";
        std::cout << "Time to get to work!" << std::endl;
    } else {
        this->isWorking = false;
        std::cout << "Nurse " << this->id << ": ";
        std::cout << "Time to go home to my eucalyptus forest!" << std::endl;
    }
}
