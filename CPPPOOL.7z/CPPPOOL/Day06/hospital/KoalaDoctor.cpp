/*
** EPITECH PROJECT, 2021
** day 6 ex 2 cpp
** File description:
** day 6 ex 2 cpp
*/

#include <iostream>
#include <fstream>
#include <string>
#include "KoalaDoctor.hpp"
#include "SickKoala.hpp"

KoalaDoctor::KoalaDoctor(std::string name)
{
    this->name = name;
    this->isWorking = false;
    std::cout << "Dr." << this->name << ": ";
    std::cout << "I'm Dr." << this->name << "! ";
    std::cout << "How do you kreog?" << std::endl;
}

KoalaDoctor::~KoalaDoctor()
{
    this->name.empty();
}

void KoalaDoctor::diagnose(SickKoala *SickKoala)
{
    char const *my_list[5];
    char const *ext = ".report";
    std::string filename;

    filename.assign(SickKoala->getName());
    std::cout << "Dr." << this->name << ": ";
    std::cout << "So what's goerking you Mr.";
    std::cout << SickKoala->getName() << "?" << std::endl;
    SickKoala->poke();
    my_list[0] = "Mars";
    my_list[1] = "Kinder";
    my_list[2] = "Crunch";
    my_list[3] = "Maroilles";
    my_list[4] = "Eucalyptus leaf";
    for (int i = 0; ext[i] != '\0'; i++)
        filename.push_back(ext[i]);
    std::ofstream file(filename);
    if (file)
        file << my_list[random() % 5] << std::endl;
}

void KoalaDoctor::timeCheck()
{
    if (this->isWorking == false) {
        this->isWorking = true;
        std::cout << "Dr." << this->name << ": ";
        std::cout << "Time to get to work!" << std::endl;
    } else {
        this->isWorking = false;
        std::cout << "Dr." << this->name << ": ";
        std::cout << "Time to go home to my eucalyptus forest!" << std::endl;
    }
}
