/*
** EPITECH PROJECT, 2021
** day 6 ex 2 cpp
** File description:
** day 6 ex 2 cpp
*/

#include <iostream>
#include <string>
#include "SickKoala.hpp"

SickKoala::SickKoala(std::string name)
{
    this->name = name;
}

SickKoala::~SickKoala()
{
    std::cout << "Mr." << this->name << ": ";
    std::cout << "Kreooogg!! I'm cuuuured!" << std::endl;
    this->name.empty();
}

void SickKoala::poke()
{
    std::cout << "Mr." << this->name << ": ";
    std::cout << "Gooeeeeerrk!!" << std::endl;
}

bool SickKoala::takeDrug(std::string str)
{
    std::string mars = "Mars";
    std::string kinder = "Kinder";
    
    if (str.compare(mars) == 0) {
        std::cout << "Mr." << this->name << ": ";
        std::cout << "Mars, and it kreogs!" << std::endl;
        return (true);
    }
    else if (str.compare(kinder) == 0) {
        std::cout << "Mr." << this->name << ": ";
        std::cout << "There is a toy inside!" << std::endl;
        return (true);
    }
    else {
        std::cout << "Mr." << this->name << ": ";
        std::cout << "Goerkreog!" << std::endl;
        return (false);
    }
}

void SickKoala::overDrive(std::string str)
{
    size_t pos = 0;

    while ((pos = str.find("Kreog!", pos)) != std::string::npos)
        str.replace(pos, 6, "1337!");
    std::cout << "Mr." << this->name << ": ";
    std::cout << str << std::endl;
}

std::string SickKoala::getName()
{
    return (this->name);
}
