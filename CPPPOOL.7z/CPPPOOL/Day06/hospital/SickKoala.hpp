/*
** EPITECH PROJECT, 2021
** day 6 ex 2 cpp
** File description:
** day 6 ex 2 cpp
*/

#ifndef _SICKKOALA_
#define _SICKKOALA_

#include <string>

class SickKoala
{
    std::string name;

public :
    SickKoala(std::string name);
    ~SickKoala();
    void poke();
    bool takeDrug(std::string str);
    void overDrive(std::string str);
    std::string getName();
};

#endif
