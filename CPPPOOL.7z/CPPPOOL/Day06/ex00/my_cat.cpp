/*
** EPITECH PROJECT, 2021
** day 6 ex 0 cpp
** File description:
** day 6 ex 0 cpp
*/

#include <iostream>
#include <fstream>
#include <istream>

void my_cat(char *av)
{
    std::ifstream file(av);

    if (file) {
        std::cout << file.rdbuf();
    }
    else
        std::cerr << "my_cat: " << av << ": No such file or directory" << std::endl;
}
