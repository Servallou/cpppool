/*
** EPITECH PROJECT, 2021
** day 6 ex 0 cpp
** File description:
** day 6 ex 0 cpp
*/

#include <iostream>

void my_cat(char *file);

int main(int ac, char **av)
{
    if (ac == 1)
        std::cerr << "my_cat: Usage: ./my_cat file [...]" << std::endl;
    else
        for (int i = 1; i != ac; i++)
            my_cat(av[i]);
    return (0);
}
