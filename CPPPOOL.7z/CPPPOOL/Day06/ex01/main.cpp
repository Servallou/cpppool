/*
** EPITECH PROJECT, 2021
** day 6 ex 1 cpp
** File description:
** day 6 ex 1 cpp
*/

#include <iostream>
#include <string>

void my_convert_fahrenheit(float nb);
void my_convert_celsius(float nb);

int main(void)
{
    float nb;
    std::string temp;

    std::cin >> nb >> temp;
    if (temp.compare("Celsius"))
        my_convert_celsius(nb);
    else if (temp.compare("Fahrenheit"))
        my_convert_fahrenheit(nb);
    else
        return (84);
    return (0);
}
