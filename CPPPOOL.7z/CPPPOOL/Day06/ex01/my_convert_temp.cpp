/*
** EPITECH PROJECT, 2021
** day 6 ex 1 cpp
** File description:
** day 6 ex 1 cpp
*/

#include <iostream>
#include <iomanip>

void my_convert_celsius(float nb)
{
    float celsius = 5.0 / 9.0;

    celsius *= nb - 32;
    std::cout << std::setprecision(3) << std::setw(16);
    std::cout << std::fixed << celsius << std::setw(16);
    std::cout << "Celsius" << std::endl;
}

void my_convert_fahrenheit(float nb)
{
    float fahrenheit = 9.0 * nb;

    fahrenheit /= 5;
    fahrenheit += 32;
    std::cout << std::setprecision(3) << std::setw(16);
    std::cout << std::fixed << fahrenheit << std::setw(16);
    std::cout << "Fahrenheit" << std::endl;
}
