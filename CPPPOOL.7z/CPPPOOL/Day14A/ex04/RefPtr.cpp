/*
** EPITECH PROJECT, 2021
** Day 14 a ex00 
** File description:
** day 14 a ex00
*/

#include "RefPtr.hpp"

RefPtr::RefPtr(BaseComponent *rawPtr) : _rawPtr(rawPtr), _refCounter(new int)
{
    *_refCounter = 1;
}

RefPtr::RefPtr(RefPtr const &other)
{
    this->_rawPtr = other.get();
    this->_refCounter++;
}

RefPtr::~RefPtr()
{
    if (this->_refCounter == 0)
        delete this->_rawPtr;
}

BaseComponent *RefPtr::get() const
{
    return this->_rawPtr;
}

RefPtr &RefPtr::operator=(RefPtr const &other)
{
    if (this->_refCounter == 0)
        delete this->_rawPtr;
    this->_rawPtr = other.get();
    this->_refCounter = other._refCounter;
    this->_refCounter++;
    return *this;
}