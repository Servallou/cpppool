/*
** EPITECH PROJECT, 2021
** Day 14 a ex00 
** File description:
** day 14 a ex00
*/

#ifndef REF_PTR_HPP_
#define REF_PTR_HPP_

#include <cstddef>
#include "BaseComponent.hpp"

class RefPtr
{
    public:
        RefPtr(BaseComponent *rawPtr);
        RefPtr(RefPtr const &other);
        RefPtr() : RefPtr(nullptr) {}
        RefPtr &operator=(RefPtr const &other);
        ~RefPtr();

        BaseComponent *get() const;

    private:
        BaseComponent *_rawPtr;
        int *_refCounter;
};

#endif // REF_PTR_HPP_
