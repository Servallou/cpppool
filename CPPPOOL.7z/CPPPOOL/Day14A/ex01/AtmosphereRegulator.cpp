
#include "Errors.hpp"
#include "AtmosphereRegulator.hpp"

AtmosphereRegulator::AtmosphereRegulator()
{
    throw NasaError("Not implemented.", "AtmosphereRegulator");
}

AtmosphereRegulator::~AtmosphereRegulator()
{
}
