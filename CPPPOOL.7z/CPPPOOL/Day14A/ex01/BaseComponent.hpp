
#ifndef BASE_COMPONENT_HPP_
#define BASE_COMPONENT_HPP_

// Base class for all rover's components.
class BaseComponent
{
    public:
        virtual ~BaseComponent() = default;
};

#endif // BASE_COMPONENT_HPP_
