/*
** EPITECH PROJECT, 2021
** Day 14 a ex00 
** File description:
** day 14 a ex00
*/

#include "SimplePtr.hpp"

SimplePtr::SimplePtr(BaseComponent *rawPtr) : _rawPtr(rawPtr)
{

}

SimplePtr::SimplePtr(SimplePtr const &ptr)
{
    this->_rawPtr = ptr.get();
}

SimplePtr::~SimplePtr()
{
    delete _rawPtr;
}

BaseComponent *SimplePtr::get() const 
{
    return _rawPtr;
}

SimplePtr &SimplePtr::operator=(SimplePtr const &ptr)
{
    this->_rawPtr = ptr.get();
    return *this;
}
