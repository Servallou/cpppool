/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Elf
*/

#ifndef ELF_HPP_
#define ELF_HPP_

#include "IElf.hpp"
#include "PapaXmasConveyorBelt.hpp"
#include "PapaXmasTable.hpp"

class Elf : public IElf {
    public:
        Elf();
        ~Elf();

        void convOUT() const override;
        void convIN() const override;
        bool convPut(Object *obj) const override;
        Object *convTake() const override;
        const std::string &convLook() const override;
        bool tablePut(Object *obj) const override;
        Object *tableTake() const override;
        Object *tableTake(Object::ObjectType type) const override;
        const std::string **tableLook() const override;

        Object *wrapGift(Toy *toy, Box *box, GiftPaper *paper) const override;
        Object *createGift() const override;
        void work() const override;
    protected:
        ITable *_table;
        IConveyorBelt *_conv;
};

#endif