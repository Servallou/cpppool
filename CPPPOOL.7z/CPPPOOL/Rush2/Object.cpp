/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Object
*/

#include "Object.hpp"

Object::Object(const std::string &name, ObjectType type) :
    name(name),
    type(type)
{
}

Object::~Object()
{
}

std::ostream &operator<<(std::ostream &out, const Object &obj)
{
    return out << "Object " << obj.getName();
}

const std::string &Object::getName() const
{
    return this->name;
}

Object::ObjectType Object::getType() const
{
    return this->type;
}