#include <iostream>
#include "Object.hpp"
#include "Teddy.hpp"
#include "Box.hpp"
#include "GiftPaper.hpp"
#include "PapaXmasConveyorBelt.hpp"
#include "PapaXmasTable.hpp"
#include "Elf.hpp"

Object *MyUnitTests(Object **arr);
Object **MyUnitTests();

int main() {
    Object **arr = MyUnitTests();
    Object **arr2_test = new Object*[3];
    Elf *elf = new Elf();

    arr2_test[0] = new Teddy("teddy");
    arr2_test[1] = new Box("Box");
    arr2_test[2] = new GiftPaper("GiftPaper that will become Gift");

    for (int i = 0; i < 2; i++)
        std::cout << *arr[i] << std::endl;
    std::cout << *MyUnitTests(arr2_test) << std::endl;
    elf->work();
}