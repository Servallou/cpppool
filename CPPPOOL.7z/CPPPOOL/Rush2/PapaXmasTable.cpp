/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** PapaXmasTable
*/

#include "PapaXmasTable.hpp"
#include "Teddy.hpp"
#include "LittlePony.hpp"
#include "Box.hpp"
#include "GiftPaper.hpp"

PapaXmasTable::PapaXmasTable()
{
}

PapaXmasTable::~PapaXmasTable()
{
}

bool PapaXmasTable::Put(Object *object)
{
    if (object == nullptr) {
        std::cerr << "Childrens can't have empty gift :(" << std::endl;
        return false;
    }
    if (this->_list.size() >= 10) {
        std::cerr << "Table is crumbeling ! YA DANCE DANCE ON BAGPIPE !" << std::endl;
        return false;
    }
    this->_list.push_back(object);
    return true;
}

Object *PapaXmasTable::Take()
{
    Object *obj = nullptr;

    this->_list.remove(nullptr);
    if (this->_list.empty()) {
        std::cerr << "No Object for ya elf!" << std::endl;
        return nullptr;
    }
    obj = _list.front();
    obj->isTaken();
    this->_list.pop_front();
    return obj;
}

Object *PapaXmasTable::Take(Object::ObjectType type)
{
    Object *obj = nullptr;
    std::string arr[3] = {"Toy", "Box", "Gift Paper"};

    this->_list.remove(nullptr);
    if (this->_list.empty()) {
        std::cerr << "No " << arr[type] << " in the table for ya elf!" << std::endl;
        return nullptr;
    }
    for (Object *ob : this->_list)
        if (ob->getType() == type) {
            obj = ob;
            break;
        }
    if (obj != nullptr) {
        this->_list.remove(obj);
        obj->isTaken();
    }
    return obj;
}

const std::string **PapaXmasTable::Look() const
{
    int size = this->_list.size();
    const std::string **looks;
    int i = 0;

    if (size < 1) {
        std::cerr << "Not even a sad cookie left on this table !!" << std::endl;
        return nullptr;
    }
    looks = new std::string const *[size + 1];
    for (Object *obj : _list)
        looks[i++] = &obj->getName();
    looks[size] = nullptr;
    return looks;
}

ITable *createTable()
{
    ITable *table = new PapaXmasTable();

    table->Put(new Teddy("Bad teddy"));
    table->Put(new LittlePony("Not a unicorn"));
    table->Put(new Box("Box1"));
    table->Put(new Box("Box2"));
    table->Put(new GiftPaper("Gift Paper 1"));
    table->Put(new GiftPaper("Gift Paper 2"));
    return table;
}

std::list<Object *> *PapaXmasTable::getList()
{
    return &this->_list;
}