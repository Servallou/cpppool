/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Object
*/

#ifndef OBJECT_HPP_
#define OBJECT_HPP_

#include <iostream>
#include <string>

class Object {
    public:
        enum ObjectType
        {
            TOY,
            BOX,
            GIFTPAPER
        };
        Object(const std::string &name, ObjectType type);
        virtual ~Object();

        virtual void isTaken() = 0;
        const std::string &getName() const;
        ObjectType getType() const;
    protected:
        bool _isTaken;
        std::string name;
        ObjectType type;
};
std::ostream &operator<<(std::ostream &out, const Object &obj);

#endif