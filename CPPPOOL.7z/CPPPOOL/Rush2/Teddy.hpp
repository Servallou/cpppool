/*
** EPITECH PROJECT, 2021
** rush2
** File description:
** Teddy
*/

#ifndef TEDDY_HPP_
#define TEDDY_HPP_

#include "Toy.hpp"

class Teddy : public Toy
{
    public:
        explicit Teddy(const std::string &name);
        ~Teddy();

        void isTaken() override;
};

#endif