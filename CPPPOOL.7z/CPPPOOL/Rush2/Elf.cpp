/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Elf
*/

#include "Elf.hpp"
#include "Box.hpp"
#include "GiftPaper.hpp"
#include "Toy.hpp"

Elf::Elf()
{
    this->_table = createTable();
    this->_conv = createConveyorBelt();
}

Elf::~Elf()
{
}

Object *Elf::wrapGift(Toy *toy, Box *box, GiftPaper *paper) const
{
    if (!box->isOpen())
        box->openMe();
    box->wrapMeThat(toy);
    box->closeMe();
    paper->wrapMeThat(box);
    return (Object *)paper;
}

Object *Elf::createGift() const
{
    Box *box = (Box *)tableTake(Object::BOX);
    Toy *toy = (Toy *)tableTake(Object::TOY);
    GiftPaper *paper = (GiftPaper *)tableTake(Object::GIFTPAPER);
    Wrap *wrap = NULL;

    if (box == nullptr && paper != nullptr) {
        if (convLook().empty())
            convIN();
        wrap = (Wrap *)convTake();
        if (wrap->getType() != Object::BOX)
            return nullptr;
        box = (Box *) wrap;
    }
    if (paper == nullptr && box != nullptr) {
        if (convLook().empty())
            convIN();
        wrap = (Wrap *)convTake();
        if (wrap->getType() != Object::GIFTPAPER)
            return nullptr;
        paper = (GiftPaper *) wrap;
    }
    if (box == nullptr || toy == nullptr || paper == nullptr)
        return nullptr;
    return wrapGift(toy, box, paper);
}

void Elf::work() const
{
    for (Object *gift = createGift(); gift != nullptr; gift = createGift()) {
        convPut(gift);
        convOUT();
    }
}

void Elf::convOUT() const
{
    this->_conv->OUT();
}

void Elf::convIN() const
{
    this->_conv->IN();
}

bool Elf::convPut(Object *obj) const
{
    return this->_conv->Put(obj);
}

Object *Elf::convTake() const
{
    return this->_conv->Take();
}

const std::string &Elf::convLook() const
{
    return this->_conv->Look();
}

bool Elf::tablePut(Object *obj) const
{
    return this->_table->Put(obj);
}

Object *Elf::tableTake() const
{
    return this->_table->Take();
}

Object *Elf::tableTake(Object::ObjectType type) const
{
    return this->_table->Take(type);
}

const std::string **Elf::tableLook() const
{
    return this->_table->Look();
}