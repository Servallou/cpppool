/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Box
*/

#ifndef BOX_HPP_
#define BOX_HPP_

#include "Wrap.hpp"

class Box : public Wrap {
    public:
        Box(const std::string &name);
        ~Box();

        bool wrapMeThat(Object *obj) override;
        void closeMe();
};

#endif