/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Wrap
*/

#ifndef WRAP_HPP_
#define WRAP_HPP_

#include "Object.hpp"

class Wrap : public Object {
    public:
        Wrap(const std::string &name, ObjectType type);
        ~Wrap();

        void isTaken() override;
        virtual bool wrapMeThat(Object *obj);
        void openMe();

        bool isOpen();
    protected:
        bool _isOpen;
        Object *_obj;
};

#endif