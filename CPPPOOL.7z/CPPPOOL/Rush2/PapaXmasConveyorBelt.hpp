/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** PapaXmasConveyorBelt
*/

#ifndef PAPAXMASCONVEYORBELT_HPP_
#define PAPAXMASCONVEYORBELT_HPP_

#include <vector>

#include "Object.hpp"
#include "IConveyorBelt.hpp"

class PapaXmasConveyorBelt : public IConveyorBelt{
    public:
        explicit PapaXmasConveyorBelt();
        ~PapaXmasConveyorBelt();

        Object *Take() override;
        bool Put(Object *) override;
        void IN() override;
        void OUT() override;
        std::string const &Look() const override;

    protected:
        Object *_content;
        std::string _list;
};

IConveyorBelt *createConveyorBelt();

#endif /* !PAPAXMASCONVEYORBELT_HPP_ */
