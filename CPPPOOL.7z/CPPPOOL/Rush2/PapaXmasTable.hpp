/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** PapaXmasTable
*/

#ifndef PAPAXMASTABLE_HPP_
#define PAPAXMASTABLE_HPP_


#include "ITable.hpp"

class PapaXmasTable : public ITable{
    public:
        PapaXmasTable();
        ~PapaXmasTable();
        Object* Take() override;
        Object *Take(Object::ObjectType) override;
        bool Put(Object *object) override;
        const std::string **Look() const override;

        std::list<Object *> *getList() override;
    protected:
        std::list<Object *> _list;
    private:
};

ITable *createTable();

#endif /* !PAPAXMASTABLE_HPP_ */
