/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** Itable
*/

#ifndef ITABLE_HPP_
#define ITABLE_HPP_

#include <list>
#include "Object.hpp"

class ITable {
    public:
        virtual ~ITable() {};
        virtual Object *Take() = 0;
        virtual Object *Take(Object::ObjectType) = 0;
        virtual bool Put(Object *) = 0;
        virtual const std::string **Look() const = 0;
        virtual std::list<Object *> *getList() = 0;
};

#endif /* !ITABLE_HPP_ */
