/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** IConveyorBelt
*/

#ifndef ICONVEYORBELT_HPP_
#define ICONVEYORBELT_HPP_

#include <vector>
#include "Object.hpp"

class IConveyorBelt {
    public:
        virtual ~IConveyorBelt() {};
        virtual Object *Take() = 0;
        virtual bool Put(Object *) = 0;
        virtual void IN() = 0;
        virtual void OUT() = 0;
        virtual std::string const &Look() const = 0;
};

#endif /* !ICONVEYORBELT_HPP_ */
