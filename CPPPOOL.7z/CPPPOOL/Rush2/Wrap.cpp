/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Wrap
*/

#include "Wrap.hpp"

Wrap::Wrap(const std::string &name, ObjectType type) :
    Object(name, type),
    _isOpen(false),
    _obj(nullptr)
{
}

Wrap::~Wrap()
{
}

void Wrap::isTaken() {
  std::cout << "whistles while working" << std::endl;
}

bool Wrap::wrapMeThat(Object *obj)
{
    if (obj == nullptr || this->_obj != nullptr)
        return false;
    this->_obj = obj;
    return true;
}

void Wrap::openMe()
{
    this->_isOpen = true;
}

bool Wrap::isOpen()
{
    return this->_isOpen;
}