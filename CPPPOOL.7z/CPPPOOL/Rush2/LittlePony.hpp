/*
** EPITECH PROJECT, 2021
** rush2
** File description:
** LittlePony
*/

#ifndef LITTLEPONY_HPP
#define LITTLEPONY_HPP

#include "Toy.hpp"

class LittlePony : public Toy
{
    public :
        explicit LittlePony(const std::string &name);
        ~LittlePony();

        void isTaken() override;
};

#endif