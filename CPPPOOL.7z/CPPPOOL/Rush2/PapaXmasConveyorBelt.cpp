/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** PapaXmasConveyorBelt
*/

#include "PapaXmasConveyorBelt.hpp"
#include "Box.hpp"
#include "GiftPaper.hpp"

PapaXmasConveyorBelt::PapaXmasConveyorBelt() : _content(NULL), _list()
{
}

PapaXmasConveyorBelt::~PapaXmasConveyorBelt()
{
    delete this->_content;
}

Object* PapaXmasConveyorBelt::Take()
{
    Object *buffer;

    if (_content == NULL) {
        std::cerr << "YA DUNCE! THE CONVEYER TABLE IS EMPTY! GET TO YER WORK OR NO PENNIES FOR YA!" << std::endl;
        return NULL;
    } else {
        _content->isTaken();
        buffer = _content;
        this->_content = NULL;
        this->_list = std::string();
        return buffer;
    }
}


bool PapaXmasConveyorBelt::Put(Object *obj)
{
    if (this->_content != NULL) {
        std::cerr << "YA DUNCE! THE CONVEYER TABLE AIN'T NO EMPTY!" << std::endl;
        return false;
    } else {
        this->_content = obj;
        this->_list = obj->getName();
        return true;
    }
}

void PapaXmasConveyorBelt::IN()
{
    static int index = 0;

    if (_content != NULL) {
        std::cerr << "YA DUNCE! THE CONVEYER TABLE AIN'T NO EMPTY!" << std::endl;
        return;
    } else {
        switch (index % 2) {
            case 0:
                this->_content = new Box("Box");
                index += 1;
                this->_list = this->_content->getName();
                return;
            default:
                this->_content = new GiftPaper("Gift Paper");
                index += 1;
                this->_list = this->_content->getName();
        }
    }
}

void PapaXmasConveyorBelt::OUT()
{
    if (_content == NULL) {
        std::cerr << "YA DUNCE! THE CONVEYER TABLE IS EMPTY! GET TO YER WORK OR NO PENNIES FOR YA!" << std::endl;
        return;
    } else {
        std::cout << "Sent " << this->_content->getName() << " to Santa" << std::endl;
        delete this->_content;
        this->_content = NULL;
        this->_list = std::string();
        return;
    }
}

std::string const &PapaXmasConveyorBelt::Look() const {
    return this->_list;
}

IConveyorBelt *createConveyorBelt()
{
    return new PapaXmasConveyorBelt;
}