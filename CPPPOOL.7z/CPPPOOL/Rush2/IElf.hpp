/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** IElf
*/

#ifndef IELF_HPP_
#define IELF_HPP_

#include "Object.hpp"
#include "GiftPaper.hpp"
#include "Box.hpp"
#include "Toy.hpp"

class IElf {
    public:
        virtual ~IElf() {};

        virtual void convOUT() const = 0;
        virtual void convIN() const = 0;
        virtual bool convPut(Object *obj) const = 0;
        virtual Object *convTake() const = 0;
        virtual const std::string &convLook() const = 0;
        virtual bool tablePut(Object *obj) const = 0;
        virtual Object *tableTake() const = 0;
        virtual Object *tableTake(Object::ObjectType type) const = 0;
        virtual const std::string **tableLook() const = 0;

        virtual Object *wrapGift(Toy *toy, Box *box, GiftPaper *paper) const = 0;
        virtual Object *createGift() const = 0;
        virtual void work() const = 0;
};

#endif