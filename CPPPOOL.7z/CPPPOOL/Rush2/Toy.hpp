/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** Toy
*/

#ifndef TOY_HPP_
#define TOY_HPP_

#include "Object.hpp"

class Toy : public Object{
    public:
        explicit Toy(const std::string &name);
        ~Toy();

    protected:
    private:
};

#endif /* !TOY_HPP_ */