/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** GiftPaper
*/

#include "GiftPaper.hpp"

GiftPaper::GiftPaper(const std::string &name) :
    Wrap(name, Object::GIFTPAPER)
{
}

GiftPaper::~GiftPaper()
{
}