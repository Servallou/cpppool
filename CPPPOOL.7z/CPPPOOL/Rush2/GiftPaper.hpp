/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** GiftPaper
*/

#ifndef GIFTPAPER_HPP_
#define GIFTPAPER_HPP_

#include "Wrap.hpp"

class GiftPaper : public Wrap {
    public:
        GiftPaper(const std::string &name);
        ~GiftPaper();
};

#endif