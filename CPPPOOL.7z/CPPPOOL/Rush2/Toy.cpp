/*
** EPITECH PROJECT, 2021
** rush2 [WSL: Ubuntu]
** File description:
** Toy
*/

#include "Toy.hpp"

Toy::Toy(const std::string &name) :
    Object(name, Object::TOY)
{
}

Toy::~Toy()
{
}
