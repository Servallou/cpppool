/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush2-mihailo.pavlovic [WSL]
** File description:
** Object
*/

#include <iostream>
#include "LittlePony.hpp"
#include "Teddy.hpp"
#include "Box.hpp"
#include "GiftPaper.hpp"

Object **MyUnitTests()
{
    Object **arr = new Object*[2];

    arr[0] = new LittlePony("happy pony");
    arr[1] = new Teddy("cuddles");
    return arr;
}

Object *MyUnitTests(Object **arr)
{
    if (arr == nullptr) {
        std::cerr << "Empty list is not valid" << std::endl;
        return nullptr;
    }
    else if (!dynamic_cast<Teddy *>(arr[0]) || !dynamic_cast<Box *>(arr[1]) || !dynamic_cast<GiftPaper *>(arr[2])) {
        std::cerr << "One of the given object was not in the following type order : Teddy *, Box *, GiftPaper *" << std::endl;
        return nullptr;
    }
    if (!((Box *)arr[1])->isOpen())
        ((Box *)arr[1])->openMe();
    ((Box *)arr[1])->wrapMeThat(arr[0]);
    ((GiftPaper *)arr[2])->wrapMeThat(arr[1]);
    return (arr[2]);
}