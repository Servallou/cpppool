/*
** EPITECH PROJECT, 2021
** day 07 a ex 0 cpp
** File description:
** day 07 a ex 0 cpp
*/

#include <iostream>
#include "Skat.hpp"

Skat::Skat(std::string name, int stimPaks)
{
    this->_name = name;
    this->_stimPaks = stimPaks;
}

Skat::~Skat()
{

}

int Skat::stimPaks()
{
    return (this->_stimPaks);
}

const std::string &Skat::name()
{
    return(this->_name);
}

void Skat::shareStimPaks(int nb, int &stock)
{
    if (this->_stimPaks - nb <= 0) {
        stock += this->_stimPaks;
        this->_stimPaks = 0;
        std::cout << "Don't be greedy" << std::endl;
    } else {   
        stock += nb;
        this->_stimPaks -= nb;
        std::cout << "Keep the change." << std::endl;
    }
}

void Skat::addStimPaks(unsigned int nb)
{
    if (nb == 0)
        std::cout << "Hey boya, did you forget something?" << std::endl;
    else
        this->_stimPaks += nb;    
}

void Skat::useStimPaks()
{
    if (this->_stimPaks != 0) {
        std::cout << "Time to kick sime ass and chew bubble gum." << std::endl;
        this->_stimPaks--;
    }
    else
        std::cout << "Mediiiiiic" << std::endl;    
}

void Skat::status()
{
    std::cout << "Soldier " << this->_name << " reporting ";
    std::cout << this->_stimPaks << " stimpaks remaining sir!" << std::endl;
}