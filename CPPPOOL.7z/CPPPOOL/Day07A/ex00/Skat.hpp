/*
** EPITECH PROJECT, 2021
** day 07 a ex 0 cpp
** File description:
** day 07 a ex 0 cpp
*/

#ifndef _SKAT_
#define _SKAT_

#include <string>

class Skat
{
private:
    std::string _name;
    int _stimPaks;
public:
    Skat(std::string name = "bob", int stimPaks = 15);
    ~Skat();
    int stimPaks();
    const std::string &name();
    void shareStimPaks(int number, int &stock);
    void addStimPaks(unsigned int nb);
    void useStimPaks();
    void status();
};


#endif