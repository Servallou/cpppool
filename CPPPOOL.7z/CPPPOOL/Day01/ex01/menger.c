/*
** EPITECH PROJECT, 2021
** day 1 exo 1
** File description:
** day 1 exo 1
*/

#include <stdio.h>

void menger(int a, int level, int x, int y)
{
    a = a / 3;
    printf("%03d %03d %03d\n", a, x + a, y + a);
    if (level > 1) {
        level--;
        menger(a, level, x, y);
        menger(a, level, x, y + a);
        menger(a, level, x, y + (a * 2));
        menger(a, level, x + a, y);
        menger(a, level, x + a, y + (a * 2));
        menger(a, level, x + (2 * a), y);
        menger(a, level, x + (2 * a), y + a);
        menger(a, level, x + (2 * a), y + (2 * a));
    }
}
