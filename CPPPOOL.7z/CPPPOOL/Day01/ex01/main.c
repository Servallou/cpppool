/*
** EPITECH PROJECT, 2021
** exo 1 day 1
** File description:
** exo 1 day 1
*/

#include "menger.h"
#include <stdlib.h>
#include <stdio.h>

int error_handling(int a)
{
    if (a < 0)
        return (1);
    if (a % 3 == 1)
        return (1);
    return (0);
}

int main(int ac, char **av)
{
    int a;
    int b;
    int x = 0;
    int y = 0;

    if (ac != 3)
        return (84);
    a = atoi(av[1]);
    b = atoi(av[2]);
    if (error_handling(a) == 1)
        return (84);
    if (b == 1) {
        printf("%03d %03d %03d\n", a / 3, a / 3, a / 3);
        return (0);
    }
    menger(a, b, x, y);
    return (0);
}
