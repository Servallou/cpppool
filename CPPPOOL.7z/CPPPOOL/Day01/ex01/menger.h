/*
** EPITECH PROJECT, 2021
** day 1 exo 1
** File description:
** day 1 exo 1
*/

#ifndef _MENGER_H_
#define _MENNGER_H_

void menger(int a, int b, int x, int y);

#endif
