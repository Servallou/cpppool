/*
** EPITECH PROJECT, 2021
** exo 0 day 1
** File description:
** exo 0 day 1
*/

#include <stdio.h>

int main(int ac, char **av)
{
    printf("z\n");
    return (0);
}
