/*
** EPITECH PROJECT, 2021
** day 10 ex 00
** File description:
** day 10 ex 00
*/

#ifndef _PEON_
#define _PEON_

#include <string>
#include "Victim.hpp"

class Peon : public Victim
{
public :
    Peon(std::string const name);
    ~Peon();
    void getPolymorphed() const override;
};

#endif