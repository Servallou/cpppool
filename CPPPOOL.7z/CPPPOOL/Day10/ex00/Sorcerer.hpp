/*
** EPITECH PROJECT, 2021
** day 10 ex 00
** File description:
** day 10 ex 00
*/

#ifndef _SORCERER_
#define _SORCERER_

#include <string>
#include "Victim.hpp"

class Sorcerer
{
private :
    std::string name;
    std::string title;
public  :
    Sorcerer(std::string const name, std::string const title);
    ~Sorcerer();
    std::string getName() const;
    std::string getTitle() const;
    void polymorph(const Victim &vitim);
};

std::ostream& operator <<(std::ostream& out, Sorcerer const &sorcerer);

#endif