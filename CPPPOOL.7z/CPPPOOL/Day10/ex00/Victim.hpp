/*
** EPITECH PROJECT, 2021
** day 10 ex 00
** File description:
** day 10 ex 00
*/

#ifndef _VICTIM_
#define _VICTIM_

#include <string>

class Victim
{
protected :
    std::string name;
public :
    Victim(std::string const name);
    ~Victim();
    std::string getName() const;
    virtual void getPolymorphed() const;
};

std::ostream& operator <<(std::ostream& out, Victim const &victim);

#endif