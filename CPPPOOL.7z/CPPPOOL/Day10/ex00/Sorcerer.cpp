/*
** EPITECH PROJECT, 2021
** day 10 ex 00
** File description:
** day 10 ex 00
*/

#include <iostream>
#include "Sorcerer.hpp"

std::ostream& operator <<(std::ostream& out, Sorcerer const &sorcerer)
{
    out << "I am " << sorcerer.getName() << ", " << sorcerer.getTitle();
    out << ", and I like ponies!" << std::endl;
    return (out);
}

Sorcerer::Sorcerer(std::string const name, std::string const title)
{
    this->name = name;
    this->title = title;
    std::cout << this->name << ", " << this->title;
    std::cout << ", is born!" << std::endl;
}

Sorcerer::~Sorcerer()
{
    std::cout << this->name << ", " << this->title;
    std::cout << ", is dead. Consequences will never be the same!" << std::endl;
}

std::string Sorcerer::getName() const
{
    return (this->name);
}

std::string Sorcerer::getTitle() const
{
    return (this->title);
}

void Sorcerer::polymorph(const Victim &victim)
{
    victim.getPolymorphed();
}