/*
** EPITECH PROJECT, 2021
** day 10 ex 00
** File description:
** day 10 ex 00
*/

#include <iostream>
#include "Victim.hpp"

std::ostream& operator <<(std::ostream& out, Victim const &victim)
{
    out << "I'm " << victim.getName();
    out << " and I like otters!" << std::endl;
    return (out);
}

Victim::Victim(std::string const name)
{
    this->name = name;
    std::cout << "Some random victim called " << this->name;
    std::cout << " just popped!" << std::endl;   
}

Victim::~Victim()
{
    std::cout << "Victim " << this->name;
    std::cout << " just died for no apparent reason!" << std::endl;
}

std::string Victim::getName() const
{
    return (this->name);
}

void Victim::getPolymorphed() const
{
    std::cout << this->name << " has been turned into a cute little sheep!" << std::endl;
}