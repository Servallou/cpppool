/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _AWEAPON_
#define _AWEAPON_

#include <string>

class AWeapon
{
private :
    std::string name;
    int damage;
    int ap;
public :
    AWeapon(const std::string &name, int apcost, int damage);
    ~AWeapon();
    std::string getName() const;
    int getAPCost() const;
    int getDamage() const;
    virtual void attack() const = 0;
};

#endif