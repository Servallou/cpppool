/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _PLASMARIFLE_
#define _PLASMARIFLE_

#include <string>
#include "AWeapon.hpp"

class PlasmaRifle : public AWeapon
{
public :
    PlasmaRifle();
    ~PlasmaRifle();
    void attack() const;
};

#endif