/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#include <iostream>
#include "RadScorpion.hpp"

RadScorpion::RadScorpion() : AEnemy(80, "RadScorpion")
{
    std::cout << "* click click click *" << std::endl;
}

RadScorpion::~RadScorpion()
{
    std::cout << "* SPROTCH *" << std::endl;
}