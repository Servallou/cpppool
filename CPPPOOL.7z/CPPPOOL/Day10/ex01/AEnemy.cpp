/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#include "AEnemy.hpp"

AEnemy::AEnemy(int hp, const std::string &type)
{
    this->hp = hp;
    this->type = type;
}

AEnemy::~AEnemy(){}
    
void AEnemy::takeDamage(int damage)
{
    if (damage > 0)
        this->hp -= damage;
}
    
std::string AEnemy::getType() const
{
    return (this->type);
}
    
int AEnemy::getHP() const
{
    return (this->hp);
}