/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _REDSCORPION_
#define _REDSCORPION_

#include <string>
#include "AEnemy.hpp"

class RadScorpion : public AEnemy
{
public :
    RadScorpion();
    ~RadScorpion();
};

#endif