/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _CHARACTER_
#define _CHARACTER_

#include <string>
#include "AWeapon.hpp"
#include "AEnemy.hpp"

class Character
{
private :
    std::string name;
    int ap;
    AWeapon *weapon;
public :
    Character(const std::string &name);
    ~Character();
    void recoverAP();
    void equip(AWeapon *weapon);
    void attack(AEnemy *enemy);
    std::string getName() const;
    int getAP() const;
    AWeapon *getWeapon() const;
};

std::ostream& operator <<(std::ostream& out, Character const &character);

#endif