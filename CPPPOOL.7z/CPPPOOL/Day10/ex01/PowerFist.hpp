/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _POWERFIST_
#define _POWERFIST_

#include <string>
#include "AWeapon.hpp"

class PowerFist : public AWeapon
{
public :
    PowerFist();
    ~PowerFist();
    void attack() const;
};

#endif