/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#include <iostream>
#include "AWeapon.hpp"

AWeapon::AWeapon(const std::string &name, int apcost, int damage)
{
    this->name = name;
    this->ap = apcost;
    this->damage = damage;
}
AWeapon::~AWeapon(){}

std::string AWeapon::getName() const
{
    return (this->name);
}

int AWeapon::getAPCost() const
{
    return (this->ap);
}
    
int AWeapon::getDamage() const
{
    return (this->damage);
}