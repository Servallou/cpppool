/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#include <iostream>
#include "Character.hpp"

std::ostream& operator <<(std::ostream& out, Character const &character)
{
    AWeapon *weapon = character.getWeapon();
    if (weapon) {
        out << character.getName() << " has " << character.getAP();
        out << " AP and wields a " << weapon->getName() << std::endl;
    } else {
        out << character.getName() << " has " << character.getAP();
        out << " AP and is unarmed" << std::endl;
    }
    return (out);
}

Character::Character(const std::string &name)
{
    this->name = name;
    this->ap = 40;
    this->weapon = NULL;
}

Character::~Character(){}
    
void Character::recoverAP()
{
    if (this->ap + 10 >= 40)
        this->ap = 40;
    else
        this->ap += 10;
}

void Character::equip(AWeapon *weapon)
{
    this->weapon = weapon;
}

void Character::attack(AEnemy *enemy)
{
    if (this->weapon)
        if (this->ap >= this->weapon->getAPCost()) {
            std::cout << this->name << " attacks ";
            std::cout << enemy->getType() << " with a ";
            std::cout << this->weapon->getName() << std::endl;
            this->ap -= this->weapon->getAPCost();
            this->weapon->attack();
            enemy->takeDamage(this->weapon->getDamage());
            if (enemy->getHP() <= 0)
                enemy->~AEnemy();
        }
}

std::string Character::getName() const
{
    return (this->name);
}

int Character::getAP() const
{
    return (this->ap);
}

AWeapon *Character::getWeapon() const
{
    return (this->weapon);
}
