/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _AENEMY_
#define _AENEMY_

#include <string>

class AEnemy
{
private :
    int hp;
    std::string type;
public :
    AEnemy(int hp, const std::string &type);
    virtual ~AEnemy();
    virtual void takeDamage(int damage);
    std::string getType() const;
    int getHP() const;
};

#endif