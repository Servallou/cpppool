/*
** EPITECH PROJECT, 2021
** day 10 ex 01
** File description:
** day 10 ex 01
*/

#ifndef _SUPERMUTANT_
#define _SUPERMUTANT_

#include <string>
#include "AEnemy.hpp"

class SuperMutant : public AEnemy
{
public :
    SuperMutant();
    ~SuperMutant();
    void takeDamage(int damage) override;
};

#endif