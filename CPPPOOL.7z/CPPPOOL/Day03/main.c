/*
** EPITECH PROJECT, 2021
** main
** File description:
** main
*/

#include <stdio.h>
#include "string.h"

int main(void)
{
    string_t s;
//    char *st = malloc(sizeof(char) * 7);

    string_init(&s, "Me is");
    insert_c(&s, 2, " beautiful");
    printf("%s\n", s.str);
/*    printf("%d\n", s.find_c(&s, "string", 0));
    printf("%s\n", s.str);
    printf("%ld ", s.copy(&s, st, 9, 0));
    printf("%s\n", st);
    s.assign_c(&s, "Coucou");
    printf("%s\n", s.str);
    s.append_c(&s, " Tout le monde");
    printf("%s\n", s.str);
    printf("%c\n", s.at(&s, 4));
    printf("%d\n", s.size(&s));
    printf("%s\n", s.c_str(&s));
    s.clear(&s);
    printf("%s\n", s.str);
    if (s.empty(&s) == 1)
    printf("IT'S EMPTY\n");*/
    string_destroy(&s);
    return (0);
}
