/*
** EPITECH PROJECT, 2021
** day 3 ex 4
** File description:
** day 3 ex 4
*/

#include <stdlib.h>
#include "string.h"

void clear(string_t *this)
{
    free(this->str);
    this->str = malloc(sizeof(char));
    this->str[0] = '\0';
}
