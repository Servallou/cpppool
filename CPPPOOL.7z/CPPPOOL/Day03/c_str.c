/*
** EPITECH PROJECT, 2021
** day 3 ex 8
** File description:
** day 3 ex 8
*/

#include "string.h"

const char *c_str(const string_t *this)
{
    return (this->str);
}
