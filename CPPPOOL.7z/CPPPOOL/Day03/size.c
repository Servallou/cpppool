/*
** EPITECH PROJECT, 2021
** day 3 ex 5
** File description:
** day 3 ex 5
*/

#include "string.h"

int size(const string_t *this)
{
    if (this->str == NULL)
        return (-1);
    return (strlen(this->str));
}
