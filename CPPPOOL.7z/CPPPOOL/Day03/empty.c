/*
** EPITECH PROJECT, 2021
** day 3 ex 9
** File description:
** day 3 ex 9
*/

#include "string.h"

int empty(const string_t *this)
{
    if (this->str == NULL)
        return (0);
    else if (this->str[0] == '\0')
        return (1);
    else
        return (0);
}
