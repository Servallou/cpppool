/*
** EPITECH PROJECT, 2021
** day 3 ex 7
** File description:
** day 3 ex 7
*/

#include "string.h"

size_t copy(const string_t *this, char *s, size_t n, size_t pos)
{
    size_t nb = 0;

    if (pos > strlen(this->str))
        return (nb);
    while (this->str[pos] != '\0') {
        if (nb == n)
            break;
        s[nb] = this->str[pos];
        pos++;
        nb++;
    }
    if (this->str[pos] == '\0' && nb != n) {
        nb++;
        s[nb] = this->str[pos];
    }
    return (nb);
}
