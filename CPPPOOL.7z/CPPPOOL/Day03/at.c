/*
** EPITECH PROJECT, 2021
** day 3 ex 3
** File description:
** day 3 ex 3
*/

#include "string.h"

char at(const string_t *this, size_t pos)
{
    if (pos > (strlen(this->str) - 1))
        return (-1);
    return (this->str[pos]);
}
