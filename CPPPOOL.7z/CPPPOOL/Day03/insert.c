/*
** EPITECH PROJECT, 2021
** day 3 ex 11
** File description:
** day 3 ex 11
*/

#include <stdlib.h>
#include "string.h"

static void my_free(char *temp, char *temp1, string_t *this)
{
    free(this->str);
    this->str = strdup(temp1);
    free(temp);
    free(temp1);
    }

void insert_c(string_t *this, size_t pos, const char *str)
{
    char *temp;
    char *temp1;
    int a = 0;
    int t = 0;

    if (pos > strlen(this->str))
        return (append_c(this, str));
    for (size_t i = pos; this->str[i] != '\0'; i++, a++);
    temp = malloc(sizeof(char) * (a + 1));
    for (size_t i = pos, j = 0; this->str[i] != '\0'; i++, j++)
        temp[j] = this->str[i];
    temp[a] = '\0';
    temp1 = malloc(sizeof(char) * (strlen(this->str) + strlen(str) + 1));
    for (size_t i = 0; i != pos; i++, t++)
        temp1[i] = this->str[i];
    for (size_t i = pos, j = 0; str[j] != '\0'; i++, j++, t++)
        temp1[i] = str[j];
    for (int i = 0; temp[i] != '\0'; i++, t++)
        temp1[t] = temp[i];
    temp1[t] = '\0';
    my_free(temp, temp1, this);
}

void insert_s(string_t *this, size_t pos, const string_t *str)
{
    insert_c(this, pos, str->str);
}
