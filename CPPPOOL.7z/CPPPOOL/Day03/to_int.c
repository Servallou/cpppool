/*
** EPITECH PROJECT, 2021
** day 3 ex 12
** File description:
** day 3 ex 12
*/

#include <stdlib.h>
#include "string.h"

int to_int(const string_t *this)
{
    return (atoi(this->str));
}
