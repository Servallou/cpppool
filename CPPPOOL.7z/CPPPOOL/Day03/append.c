/*
** EPITECH PROJECT, 2021
** day 03 ex 2
** File description:
** day 03 ex 2
*/

#include <stdlib.h>
#include "string.h"

void append_c(string_t *this, const char *ap)
{
    int i = strlen(this->str) + strlen(ap);
    char *temp = malloc(sizeof(char) * (i + 1));

    temp = strcpy(temp, this->str);
    free(this->str);
    this->str = strcat(temp, ap);
}

void append_s(string_t *this, const string_t *ap)
{
    append_c(this, ap->str);
}
