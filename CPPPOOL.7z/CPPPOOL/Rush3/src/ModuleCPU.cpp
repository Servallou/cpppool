/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleCPU
*/

#include "ModuleCPU.hpp"
#include <time.h>
#include <algorithm>

ModuleCPU::ModuleCPU()
{
    name = "CPU";
}

ModuleCPU::~ModuleCPU()
{
}

void ModuleCPU::update(SfWindow &win)
{
    win._data.getCPUData();
    win._data.computePorcentageCPU();
    this->content = win._data.namecpu + "\nCPU : " + std::to_string(win._data.porcentage) + "%";
}