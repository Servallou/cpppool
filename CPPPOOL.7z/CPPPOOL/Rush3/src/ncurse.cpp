/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** parser
*/

#include <ncurses.h>
#include "parser.hpp"

#define ESCAPE 27

bool Data::start()
{
    int g;
    int j = 0;
    this->CycleCounter = 0;
    initscr();
    while(1) {
        int line = -3;
        clear();
        timeout(33);
        this->getTimeData();
        this->getCPUData();
        this->getRamData();
        timeout(5);
        this->computePorcentageCPU();
        this->CycleCounter += 1;
        std::string porcent = std::string("CPU : ") + std::to_string(this->porcentage) + std::string(" %%");
        std::string maxram = std::string("RAM : ") + std::to_string(this->MemMax);
            if (this->MemMax < 999)
                maxram = maxram + std::string(" GB");
            else
                maxram = maxram + std::string(" MB");
        std::string freeram = std::string("Memory free : ") + std::to_string(this->MemFree) + std::string(" MB");
        std::string availableram = std::string("Memory available : ") + std::to_string(this->MemAvailable) + std::string(" MB");
        mvprintw((LINES/ 2) + line++, (COLS / 2) -2, "x--------------------------------------------------x");
        mvprintw((LINES/ 2) + line++, (COLS / 2), ctime(&this->tt));
        for (std::vector<std::string>::const_iterator i = this->_data.begin(); i != this->_data.end(); i++, j++)
            mvprintw((LINES/ 2) + line++, (COLS / 2), this->_data[j].c_str());
        j = 0;
        mvprintw((LINES/ 2) + line++, (COLS / 2), this->namecpu.c_str());
        mvprintw((LINES/ 2) + line++, (COLS / 2), porcent.c_str());
        mvprintw((LINES/ 2) + line++, (COLS / 2), maxram.c_str());
        mvprintw((LINES/ 2) + line++, (COLS / 2), freeram.c_str());
        mvprintw((LINES/ 2) + line++, (COLS / 2), availableram.c_str());
        mvprintw((LINES/ 2) + line++, (COLS / 2) -2, "x--------------------------------------------------x");
        refresh();
        g = getch();
        if (g == ESCAPE)
            break;
    }
    endwin();
    return true;
}