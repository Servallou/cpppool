/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** SfWindow
*/

#include "SfWindow.hpp"
#include "ModuleBase.hpp"
#include "ModuleRam.hpp"
#include "ModuleCPU.hpp"

SfWindow::SfWindow(Data &data) :
    _data(data),
    win(nullptr)
{
    float x = 0;

    font.loadFromFile("font.ttf");
    modules.push_back(new ModuleBase());
    modules.push_back(new ModuleCPU());
    modules.push_back(new ModuleRam());
    for (unsigned int i = 0; i < modules.size(); i++) {
        Button *bu = new Button(modules[i]->name, {x, 0}, modules[i]);
        bu->text.setFont(font);
        buttons.push_back(bu);
        x += bu->text.getGlobalBounds().width + 20;
    }
}

SfWindow::~SfWindow()
{
}

bool SfWindow::start()
{
    sf::RenderWindow window(sf::VideoMode(500, 500), "MyGKrellm!");
    sf::Font font;
    std::string text = "";

    window.setFramerateLimit(5);
    font.loadFromFile("font.ttf");
    this->win = &window;
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::MouseButtonPressed)
                for (Button *bu : buttons) {
                    if (sf::Mouse::getPosition(window).x >= bu->text.getPosition().x
                        && sf::Mouse::getPosition(window).y >= bu->text.getPosition().y
                        && sf::Mouse::getPosition(window).x <= bu->text.getPosition().x + bu->text.getGlobalBounds().width
                        && sf::Mouse::getPosition(window).y <= bu->text.getPosition().y + bu->text.getGlobalBounds().height) {
                        bu->module->enable = !bu->module->enable;
                        break;
                        }
                }

            if (event.type == sf::Event::Resized) {
                sf::FloatRect visibleArea(0, 0, event.size.width, event.size.height);
                window.setView(sf::View(visibleArea));
            }
        }
        window.clear();
        for (Button *bu : buttons) {
            bu->text.setFont(font);
            window.draw(bu->text);
        }
        text += "\n\n";
        for (IMonitorModule *mod : modules) {
            if (!mod->enable)
                continue;
            mod->update(*this);
            text += mod->content + "\n\n";
        }
        sf::Text tex;
        tex.setFont(font);
        tex.setCharacterSize(16);
        tex.setString(text);
        window.draw(tex);
        text = "";
        window.display();
    }

    return 0;
}