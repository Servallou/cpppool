/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleRam
*/

#include "ModuleRam.hpp"
#include <time.h>
#include <algorithm>

ModuleRam::ModuleRam()
{
    name = "RAM";
}

ModuleRam::~ModuleRam()
{
}

void ModuleRam::update(SfWindow &win)
{
    win._data.getRamData();
    content = "RAM : " + std::to_string(win._data.MemMax) + (win._data.MemMax < 999 ? " GB" : " MB") +
        "\nMemory free : " + std::to_string(win._data.MemFree) + " MB" +
        "\nMemory available : " + std::to_string(win._data.MemAvailable) + " MB";

}