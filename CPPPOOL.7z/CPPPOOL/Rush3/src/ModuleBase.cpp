/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleBase
*/

#include "ModuleBase.hpp"
#include <time.h>
#include <algorithm>

ModuleBase::ModuleBase()
{
    name = "info";
}

ModuleBase::~ModuleBase()
{
}

void ModuleBase::update(SfWindow &win)
{
    struct utsname os = win._data.osData;
    char hostName[256];

    gethostname(hostName, 256);
    win._data.getTimeData();
    win._data.CycleCounter += 1;
    this->content = ctime(&win._data.tt) + std::string(os.sysname) + std::string(os.release) + "\n" + std::getenv("USER") + "\n" + hostName;
}