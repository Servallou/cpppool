/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** parser
*/

#include "parser.hpp"

void Data::setOsData()
{
    int status = uname(&osData);
    if (status == -1) {
        std::cerr << "Error !" << std::endl;
        exit(84);
    } std::string tmp = (std::string)osData.sysname + " " + (std::string)osData.release;
    this->_data.push_back(tmp);
}

void Data::setUserData()
{
    std::string userData;
    char hostName[256];
    gethostname(hostName, 256);
    userData = std::getenv("USER")/* + (std::string((char *)" ")) + getenv("USERNAME")*/;
    this->_data.push_back(userData);
    this->_data.push_back(hostName);
}

void Data::getTimeData()
{
    _clock = std::chrono::system_clock::now();
    tt = std::chrono::system_clock::to_time_t(_clock);
}