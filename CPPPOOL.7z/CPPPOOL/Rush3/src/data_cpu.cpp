#include "parser.hpp"

// Récupère dans le fichier le "model name" | "cpu MHz" | "CPu Cores" || A modifier si besoind de plus d'info
void Data::getCPUData() {
    int j = 0;
    int k = 0;
    int check = 0;
    std::vector<std::string> _data;
    std::string line;
    std::string tempcore;
    std::ifstream file("/proc/cpuinfo");

    if (!file) {
        std::cerr << "ERROR" << std::endl;
        exit(84);
    }
    while (std::getline(file, line)) {
        _data.push_back(line);
    }
    for (std::vector<std::string>::const_iterator i = _data.begin(); i != _data.end(); i++, j++) {
        if (_data[j].compare(0, 10, "model name") == 0 && k == 0) {
            this->_content.push_back(_data[j]);
            if (this->namecpu.empty() == true) {
                this->namecpu.append(_data[j]);
                this->namecpu.erase(0, 13);
            } else {
                check = 1;
            }
        }
        if (_data[j].compare(0, 7, "cpu MHz") == 0)
            this->_content.push_back(_data[j]);
        if (_data[j].compare(0, 9, "cpu cores") == 0 && k == 0) {
            this->_content.push_back(_data[j]);
            if (check == 0) {
                tempcore.append(_data[j]);
                tempcore.erase(0, 11);
                this->namecpu.append(tempcore);
                this->namecpu.append(" cores");
            }
            k++;
        }
    }
    std::string temp = this->_content[1];
    std::string temp1 = this->_content[2];
    this->_content[1].swap(temp1);
    this->_content[2].swap(temp);
    j = 2;
    for (std::vector<std::string>::const_iterator i = this->_content.begin() + 2; i != this->_content.end(); i++, j++) {
        this->_content[j].erase(0, 11);
    }
    this->_content[0].erase(0, 13);
    this->_content[1].erase(0, 11);
    file.close();
}

void Data::computePorcentageCPU()
{
    int j = 2;
    float nb = 0;
    float nb1 = 0;
    float res = 0;

    if (this->CycleCounter % 3 != 0)
        return ;
    std::string giga = this->_content[0];
    giga.erase(0, giga.find("@ ") + 2);
    if (giga.find("GHz") != 0) {
        nb = std::atof(giga.c_str()) * 1000;
    } else {
        nb = std::atof(giga.c_str()) * 100;
    }
    for (std::vector<std::string>::const_iterator i = this->_content.begin() + 2; i != this->_content.end(); i++, j++) {
        nb1 = std::atof(this->_content[j].c_str());
        res = (nb1 * 100) / nb;
        this->porcentage = res;
    }
    this->_content.clear();
    this->CycleCounter += 1;
}