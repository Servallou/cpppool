#include "parser.hpp"
#include "SfWindow.hpp"

void display_help()
{
    std::cout << "HOW TO USE :" << std::endl << std::endl;
    std::cout << "./MyGKrellm -[option]" << std::endl << std::endl;
    std::cout << "-h : display help" << std::endl;
    std::cout << "-g : graphical display with SFML" << std::endl;
    std::cout << "-t : text display with ncurse" << std::endl;
    exit (0);
}

static void error_handling(int ac, char **av, char **env)
{
    if (env == NULL) {
        std::cerr << "Hihi ENV is null!" << std::endl;
        exit(84);
    }
    if (ac != 2) {
        std::cout << "This program takes 1 argument" << std::endl;
        exit(84);
    }
    if ((std::string)av[1] == "-h")
        display_help();
    if ((std::string)av[1] == "-g" && (std::string)av[1] == "-t") {
        std::cout << "Invalid option, more information with -h" << std::endl;
        exit(84);
    }
}

int main(int ac, char **av, char **env)
{
    error_handling(ac, av, env);
    Data data;
    data.setOsData();
    data.setUserData();
    data.getCPUData();
    data.getRamData();
    data.computePorcentageCPU();
    if ((std::string)av[1] == "-t") {
        data.start();
        return 0;
    }
    else if ((std::string)av[1] == "-g") {
        SfWindow win(data);
        win.start();
        return 0;
    } else {
        return 0;
    }
}