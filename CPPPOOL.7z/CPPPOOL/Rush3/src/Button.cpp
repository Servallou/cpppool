/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** Button
*/

#include "Button.hpp"

Button::Button(std::string str, sf::Vector2f pos, IMonitorModule *mod) :
    module(mod)
{
    text.setCharacterSize(16);
    this->text.setString(str);
    this->text.setPosition(pos);
}

Button::~Button()
{
}
