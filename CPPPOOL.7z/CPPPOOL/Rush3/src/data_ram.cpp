#include "parser.hpp"

void Data::getRamData()
{
    std::ifstream file("/proc/meminfo");
    std::vector<std::string> _tmpData;
    std::vector<std::string> _buffer;
    std::string linel;
    int j = 0;
    
    if (!file) {
        std::cerr << "MemInfo not found !" << std::endl;
        exit(84);
    }
    while (std::getline(file, linel))
        _tmpData.push_back(linel);
    for (std::vector<std::string>::const_iterator i = _tmpData.begin(); i != _tmpData.end(); i++, j++) {
        if (_tmpData[j].compare(0, 8, "MemTotal") == 0)
            _buffer.push_back(_tmpData[j]);
        if (_tmpData[j].compare(0, 7, "MemFree") == 0)
            _buffer.push_back(_tmpData[j]);
        if (_tmpData[j].compare(0, 12, "MemAvailable") == 0)
            _buffer.push_back(_tmpData[j]);
    }
    _buffer[0].erase(0, 10);
    _buffer[0].erase(remove_if(_buffer[0].begin(), _buffer[0].end(), isspace), _buffer[0].end());
    _buffer[1].erase(0, 10);
    _buffer[1].erase(remove_if(_buffer[1].begin(), _buffer[1].end(), isspace), _buffer[1].end());
    _buffer[2].erase(0, 15);
    _buffer[2].erase(remove_if(_buffer[2].begin(), _buffer[2].end(), isspace), _buffer[2].end());
    this->MemMax = std::atoi(_buffer[0].c_str());
    this->MemMax /= 1000;
    if (this->MemMax > 1000)
        this->MemMax /= 1000;
    this->MemFree = std::atoi(_buffer[1].c_str());
    this->MemFree /= 1000;
    this->MemAvailable = std::atoi(_buffer[2].c_str());
    this->MemAvailable /= 1000;
}