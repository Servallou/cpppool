/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** IMonitorModule
*/

#ifndef IMONITORMODULE_HPP_
#define IMONITORMODULE_HPP_

#include "SfWindow.hpp"
#include <string>

class SfWindow;

class IMonitorModule {
    public:
        IMonitorModule() {};
        virtual ~IMonitorModule() {};

        virtual void update(SfWindow &win) = 0;
        std::string content;
        bool enable = true;
        std::string name;
};

#endif /* !IMONITORMODULE_HPP_ */