/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** main
*/

#ifndef MAIN_HPP_
#define MAIN_HPP_

#include <iostream>
#include <ios>
#include <regex>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <list>
#include <sys/utsname.h>
#include <chrono>
#include <thread>
#include <unistd.h>
#include <ctime>
#include <cstdlib>
#include <cstring>

#endif /* !MAIN_HPP_ */
