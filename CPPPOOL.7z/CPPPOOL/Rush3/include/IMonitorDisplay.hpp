/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** IMonitorDisplay
*/

#ifndef IMONITORDISPLAY_HPP_
#define IMONITORDISPLAY_HPP_

class IMonitorDisplay {
    public:
        IMonitorDisplay() {};
        virtual ~IMonitorDisplay() {};

        virtual bool start() = 0;
    protected:
    private:
};

#endif /* !IMONITORDISPLAY_HPP_ */