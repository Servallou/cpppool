/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** SfWindow
*/

#ifndef SFWINDOW_HPP_
#define SFWINDOW_HPP_

#include <SFML/Graphics.hpp>
#include <list>
#include "parser.hpp"
#include "Button.hpp"
#include "IMonitorModule.hpp"
#include "IMonitorDisplay.hpp"

class IMonitorModule;
class Button;

class SfWindow : IMonitorDisplay {
    public:
        SfWindow(Data &data);
        ~SfWindow();

        bool start() override;
        sf::Font font;
        Data &_data;
        sf::RenderWindow *win;
        std::vector<IMonitorModule *> modules;
        std::list<Button *> buttons;
};

#endif /* !SFWINDOW_HPP_ */