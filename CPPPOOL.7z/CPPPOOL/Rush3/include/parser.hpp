/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** parser
*/

#ifndef PARSER_HPP_
#define PARSER_HPP_

#include "main.hpp"
#include "IMonitorDisplay.hpp"

class Data : public IMonitorDisplay
{
    protected:

        std::chrono::system_clock::time_point _clock;

    public:
        explicit Data() { CycleCounter = 0; }
        ~Data() = default;
        std::vector<std::string> _data;
        time_t tt;
        struct utsname osData;
        std::vector<std::string> _content;
        std::string namecpu;
        float porcentage;
        int MemMax;
        int MemFree;
        int MemAvailable;
        int porcentageMem;
        int CycleCounter;

        bool start() override;
        void dataFiller();
        void setOsData();
        void setUserData();
        void getTimeData();
        void getRamData();
        void getCPUData();
        void computePorcentageCPU();
        void computePorcentageRAM();
};

#endif /* !PARSER_HPP_ */
