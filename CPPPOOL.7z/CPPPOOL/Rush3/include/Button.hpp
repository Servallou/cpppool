/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** Button
*/

#ifndef BUTTON_HPP_
#define BUTTON_HPP_

#include <SFML/Graphics.hpp>
#include <IMonitorModule.hpp>

class IMonitorModule;

class Button {
    public:
        Button(std::string str, sf::Vector2f size, IMonitorModule *mod);
        ~Button();

        sf::Text text;
        IMonitorModule *module;
};

#endif /* !BUTTON_HPP_ */