/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleCPU
*/

#ifndef MODULECPU_HPP_
#define MODULECPU_HPP_

#include "IMonitorModule.hpp"

class ModuleCPU : public IMonitorModule{
    public:
        ModuleCPU();
        virtual ~ModuleCPU();

        void update(SfWindow &win) override;
};

#endif /* !ModuleCPU_HPP_ */