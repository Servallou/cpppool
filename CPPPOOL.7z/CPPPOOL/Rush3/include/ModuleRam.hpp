/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleRam
*/

#ifndef MODULERAM_HPP_
#define MODULERAM_HPP_

#include "IMonitorModule.hpp"

class ModuleRam : public IMonitorModule{
    public:
        ModuleRam();
        virtual ~ModuleRam();

        void update(SfWindow &win) override;
};

#endif /* !ModuleRam_HPP_ */