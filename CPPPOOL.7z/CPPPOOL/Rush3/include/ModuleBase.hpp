/*
** EPITECH PROJECT, 2021
** B-CPP-300-PAR-3-2-CPPrush3-mihailo.pavlovic
** File description:
** ModuleBase
*/

#ifndef MODULEBASE_HPP_
#define MODULEBASE_HPP_

#include "IMonitorModule.hpp"

class ModuleBase : public IMonitorModule{
    public:
        ModuleBase();
        virtual ~ModuleBase();

        void update(SfWindow &win) override;
};

#endif /* !MODULEBASE_HPP_ */