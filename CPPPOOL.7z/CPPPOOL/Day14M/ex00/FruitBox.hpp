/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef FRUITBOX_HPP
#define FRUITBOX_HPP

#include "FruitNode.hpp"

class FruitBox
{
    private :
        int _size;
        int _nbrFruits;
        FruitNode *_list;
    public :
        FruitBox(int const sizemax);
        ~FruitBox();
        int nbFruits() const;
        bool putFruit(Fruit* f);
        Fruit* pickFruit();
        FruitNode* head();
};

#endif