/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "FruitBox.hpp"

FruitBox::FruitBox(int const sizemax)
{
    this->_size = sizemax;
    this->_list = NULL;
}

FruitBox::~FruitBox()
{

}

int FruitBox::nbFruits() const
{
    return (this->_nbrFruits);
}

bool FruitBox::putFruit(Fruit *f)
{
    if (!f)
        return (false);
    if (nbFruits() == this->_size)
        return (false);
    else {
        if (this->_list == NULL) {
            this->_list = new FruitNode();
            this->_list->fruit = f;
            this->_list->next = NULL;
            this->_nbrFruits++;
            return (true);
        }
        FruitNode *node = this->_list;
        while (node->next != NULL) {
            node = node->next;
            if (node->fruit == f)
                return (false);
        }
        FruitNode *nnode = new FruitNode();
        nnode->fruit = f;
        nnode->next = NULL;
        node->next = nnode;
        this->_nbrFruits++;
        return (true);
    }
}

Fruit *FruitBox::pickFruit()
{
    Fruit *_fruit;

    if (this->_list == NULL)
        return (NULL);
    else {
        _fruit = this->_list->fruit;
        this->_list = this->_list->next;
        this->_nbrFruits--;
        return (_fruit);
    }
}

FruitNode *FruitBox::head()
{
    if (this->_list == NULL)
        return (NULL);
    else
        return (this->_list);
}