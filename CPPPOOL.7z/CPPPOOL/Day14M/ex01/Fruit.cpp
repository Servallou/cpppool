/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "Fruit.hpp"

Fruit::Fruit(std::string const &name, int vitamins)
{
    this->_name = name;
    this->_vitamins = vitamins;
}

Fruit::~Fruit()
{

}

std::string Fruit::getName() const
{
    return (this->_name);
}

int Fruit::getVitamins() const
{
    return (this->_vitamins);
}

Fruit& Fruit::operator=(Fruit const &fruit)
{
    this->_name = fruit.getName();
    this->_vitamins = fruit.getVitamins();
    return (*this);
}