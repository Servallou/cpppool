#include "Fruit.hpp"
#include "Lemon.hpp"
#include "Banana.hpp"
#include "FruitBox.hpp"

#include <iostream>

void printList(const FruitNode *tmp)
{
    while (tmp) {
        std::cout << tmp->fruit->getName() << " -> ";
        tmp = tmp->next;
    }
    std::cout << "null" << std::endl;
}

int main ()
{
    Lemon l;
    Banana b;
    Lemon l2;
    Banana b2;
    FruitBox box(5);

    std::cout << l.getVitamins() << std::endl ;
    std::cout << b.getVitamins() << std::endl ;
    std::cout << l.getName() << std::endl ;
    std::cout << b.getName() << std::endl ;
    Fruit & f = l;
    Fruit & f2 = b;
    Fruit & f3 = l;
    Fruit & f4 = l2;
    Fruit & f5 = b2;
    Fruit & f6 = l;
    Fruit & f7 = b;
    std::cout << f.getVitamins() << std::endl ;
    std::cout << f.getName() << std::endl ;
    box.putFruit(&f);
    box.putFruit(&f2);
    box.putFruit(&f3);
    box.putFruit(&f4);
    box.putFruit(&f5);
    box.putFruit(&f6);
    box.putFruit(&f7);
    box.pickFruit();
    printList(box.head());
    return 0;
}