/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef FRUITNODE_HPP
#define FRUITNODE_HPP

#include "Fruit.hpp"

typedef struct FruitNode_s
{
    Fruit *fruit;
    struct FruitNode_s *next;
} FruitNode;


#endif