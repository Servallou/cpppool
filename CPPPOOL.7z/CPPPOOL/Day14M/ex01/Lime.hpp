/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef LIME_HPP
#define LIME_HPP

#include "Lemon.hpp"

class Lime : public Lemon
{
    public :
        Lime();
        ~Lime();
};

#endif