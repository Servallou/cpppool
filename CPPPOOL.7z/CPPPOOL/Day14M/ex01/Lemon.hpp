/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef LEMON_HPP
#define LEMON_HPP

#include "Fruit.hpp"

class Lemon : public Fruit
{
    public :
        Lemon();
        ~Lemon();
};

#endif