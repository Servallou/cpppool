/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "Lemon.hpp"

Lemon::Lemon() : Fruit("lemon", 3)
{

}

Lemon::~Lemon()
{
    
}