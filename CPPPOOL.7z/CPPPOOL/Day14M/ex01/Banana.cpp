/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "Banana.hpp"

Banana::Banana() : Fruit("banana", 5)
{

}

Banana::~Banana()
{
    
}