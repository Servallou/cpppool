/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef FRUIT_HPP
#define FRUIT_HPP

#include <string>

class Fruit
{
    protected :
        std::string _name;
        int _vitamins;
    public :
        Fruit(std::string const &name, int vitamins);
        ~Fruit();
        int getVitamins() const;
        std::string getName() const;
        Fruit& operator=(Fruit const &fruit);
};

#endif