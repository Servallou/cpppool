/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#ifndef BANANA_HPP
#define BANANA_HPP

#include "Fruit.hpp"

class Banana : public Fruit
{
    public :
        Banana();
        ~Banana();
};

#endif