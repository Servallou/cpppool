/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "Lime.hpp"

Lime::Lime() : Lemon()
{
    this->_name = "lime";
    this->_vitamins = 2;
}

Lime::~Lime()
{

}