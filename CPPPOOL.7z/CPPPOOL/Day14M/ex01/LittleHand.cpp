/*
** EPITECH PROJECT, 2021
** Day 14 m ex 00
** File description:
** day 14 m ex 00
*/

#include "LittleHand.hpp"

void LittleHand::sortFruitBox(FruitBox &unsorted, FruitBox &lemons, FruitBox &bananas, FruitBox &limes)
{
    FruitBox box(unsorted.nbFruits());
    Fruit *fruit;
    
    while((fruit = unsorted.pickFruit()) != NULL) 
    {
        if (fruit->getName().compare("lemons")) {
            if (!lemons.putFruit(fruit))
                box.putFruit(fruit);
        }
        else if (fruit->getName().compare("bananas")) {
            if (!bananas.putFruit(fruit))
                box.putFruit(fruit);
        }
        else if (fruit->getName().compare("lime")) {
            if (!limes.putFruit(fruit))
                box.putFruit(fruit);
        }
        else
            box.putFruit(fruit);
    }
    while ((fruit = box.pickFruit()) != NULL)
        unsorted.putFruit(fruit);
}