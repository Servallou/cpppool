/*
** EPITECH PROJECT, 2021
** day 13 ex 06
** File description:
** day 13 ex 06
*/

#ifndef TOYSTORIE_HPP
#define TOYSTORIE_HPP

#include "Toy.hpp"

typedef bool (Toy::*speak_toy)(std::string const msg);

class ToyStory
{
public :
    ToyStory();
    ~ToyStory();
    static bool tellMeAStory(std::string filename, Toy &toy1, speak_toy speak1, Toy &toy2, speak_toy speak2);
};

#endif