/*
** EPITECH PROJECT, 2021
** day 13 ex 06
** File description:
** day 13 ex 06
*/

#include <fstream>
#include <iostream>
#include "ToyStory.hpp"

ToyStory::ToyStory()
{

}

ToyStory::~ToyStory()
{

}

bool ToyStory::tellMeAStory(std::string filename, Toy &toy1, speak_toy speak1, Toy &toy2, speak_toy speak2)
{
    std::string buf;
    std::ifstream file(filename);

    if (file) {
        std::cout << toy1.getAscii() << std::endl;
        std::cout << toy2.getAscii() << std::endl;
        for (int i = 0; std::getline(file, buf); i++) {
            if (i == 0 || i % 2 == 0) {
                if (buf.compare(0, 8, "picture:") == 0) {
                    if (toy1.setAscii(buf.substr(8)) == false) {
                        std::cout << toy1.getLastError().where();
                        std::cout << ": " << toy1.getLastError().what() << std::endl;
                        return (false);    
                    } else
                        std::cout << toy1.getAscii() << std::endl;
                    continue;
                }
                if ((toy1.*speak1)(buf) == false) {
                    std::cout << toy1.getLastError().where();
                    std::cout << ": " << toy1.getLastError().what() << std::endl;
                    return (false);
                }
            }
            else {
                if (buf.compare(0, 8, "picture:") == 0) {
                    if (toy2.setAscii(buf.substr(8)) == false) {
                        std::cout << toy2.getLastError().where();
                        std::cout << ": " << toy2.getLastError().what() << std::endl;
                        return (false);
                    } else
                        std::cout << toy2.getAscii() << std::endl;
                    continue;
                }
                if ((toy2.*speak2)(buf) == false) {
                std::cout << toy2.getLastError().where();
                std::cout << ": " << toy2.getLastError().what() << std::endl;
                return (false);
                }
            }
        }
    }
    else {
        std::cout << "Bad Story" << std::endl;
        return (false);
    }
    return (true);
}