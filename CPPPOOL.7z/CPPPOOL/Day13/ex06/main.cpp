#include <iostream>
#include "Toy.hpp"
#include "Buzz.hpp"
#include "Woody.hpp"
#include "ToyStory.hpp"

int main ()
{
    Buzz b("buzzi");
    Woody w("wood");

    ToyStory::tellMeAStory("story.txt", b, &Toy::speak_es, w, &Toy::speak);
    return 0;
}