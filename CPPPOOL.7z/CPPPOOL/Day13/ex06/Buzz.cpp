/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#include <iostream>
#include "Buzz.hpp"

Buzz::Buzz(std::string const &name, std::string const filename) : Toy(BUZZ, name, filename)
{
    
}

bool Buzz::speak(std::string const statement)
{
    std::cout << "BUZZ: " << this->getName() << " \"" << statement << "\"" << std::endl;
    return (true);
}

bool Buzz::speak_es(std::string const statement)
{
    std::cout << "BUZZ: " << this->getName() << " ";
    std::cout << "senorita \"" << statement << "\" senorita" << std::endl;
    return (true);
}