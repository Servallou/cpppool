/*
** EPITECH PROJECT, 2021
** day 13 ex 01
** File description:
** day 13 ex 01
*/

#include <istream>
#include <fstream>
#include "Picture.hpp"

Picture::Picture()
{
    this->data = "";
}

Picture::Picture(std::string const &file)
{
    std::ifstream filed(file);
    std::string line;

    if (filed)
        while(std::getline(filed, line)) {
            this->data.append(line);
            this->data.append("\n");
        }
    else
        this->data = "ERROR";
}

Picture::Picture(const Picture &picture)
{
    this->data = picture.data;
}

Picture::~Picture()
{
}

Picture& Picture::operator=(Picture const &picture)
{
    this->data = picture.data;
    return (*this);
}

bool Picture::getPictureFromFile(const std::string &file)
{
    std::ifstream filed(file);
    std::string line;

    if (filed) {
        if (this->data.empty() != true)
            this->data.clear();
        while(std::getline(filed, line)) {
            this->data.append(line);
            this->data.append("\n");
        }
        return (true);
    }
    else {
        this->data = "ERROR";
        return (false);
    }
}