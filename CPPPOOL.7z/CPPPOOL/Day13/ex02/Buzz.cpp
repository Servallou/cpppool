/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#include "Buzz.hpp"

Buzz::Buzz(std::string const &name, std::string const filename) : Toy(BUZZ, name, filename)
{
    
}