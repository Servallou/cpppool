/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#ifndef WOODY_HPP
#define WOODY_HPP

#include "Toy.hpp"

class Woody : public Toy
{
    public :
        Woody(std::string const &name, std::string const filename = "./woody.txt");
};

#endif