/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#include "Woody.hpp"

Woody::Woody(std::string const &name, std::string const filename) : Toy(WOODY, name, filename)
{

}