/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#include <iostream>
#include "Woody.hpp"

Woody::Woody(std::string const &name, std::string const filename) : Toy(WOODY, name, filename)
{

}

bool Woody::speak(std::string const statement) const
{
    std::cout << "WOODY: " << this->getName() << " \"" << statement << "\"" << std::endl;
    return (true);
}

bool Woody::speak_es(std::string const statement)
{
    (void) statement;
    this->error.type = Error::SPEAK;
    return (false);
}