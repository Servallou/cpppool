/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#ifndef BUZZ_HPP
#define BUZZ_HPP

#include "Toy.hpp"

class Buzz : public Toy
{
    public :
        Buzz(std::string const &name, std::string const filname = "./buzz.txt");
        virtual bool speak(std::string const statement) const override;
        virtual bool speak_es(std::string const statement) override;
};

#endif