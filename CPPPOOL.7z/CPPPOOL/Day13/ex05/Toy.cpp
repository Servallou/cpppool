/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#include <iostream>
#include "Toy.hpp"

std::ostream& operator <<(std::ostream &out, Toy const &toy)
{
    out << toy.getName() << std::endl << toy.getAscii() << std::endl;
    return (out);
}

Toy& Toy::operator <<(std::string const statement)
{
    this->picture.data = statement;
    return (*this);
}

Toy::Toy() 
{
    this->type = BASIC_TOY;
    this->name = "toy";
    this->picture = Picture();
}

Toy::Toy(ToyType type, std::string const &name, std::string filename)
{
    this->type = type;
    this->name = name;
    this->picture = Picture(filename);
}

Toy::Toy(const Toy &toy)
{
    this->type = toy.type;
    this->name = toy.name;
    this->picture = toy.picture;
}

Toy::~Toy()
{
}

Toy& Toy::operator=(Toy const &toy)
{
    this->type = toy.getType();
    this->name = toy.getName();
    this->picture = Picture(toy.picture);
    return (*this);
}

Toy::ToyType Toy::getType() const
{
    return (this->type);
}

std::string Toy::getName() const
{
    return (this->name);
}

void Toy::setName(std::string name)
{
    this->name = name;
}

bool Toy::setAscii(std::string filename)
{
    if (this->picture.getPictureFromFile(filename) == true)
        return (true);
    else {
        this->error.type = Toy::Error::PICTURE;
        return (false);
    }
    
}

std::string Toy::getAscii() const
{
    return (this->picture.data);
}

bool Toy::speak(std::string const statement) const
{
    std::cout << this->name << " \"" << statement <<  "\"" << std::endl;
    return (true);
}

bool Toy::speak_es(std::string const statement)
{
    (void) statement;
    this->error.type = Toy::Error::SPEAK;
    return (false);
}

std::string Toy::Error::what() const
{
    if (this->type == PICTURE)
        return ("bad new illustration");
    else if (this->type == SPEAK)
        return ("wrong mode");
    else
        return ("");    
}

std::string Toy::Error::where() const
{
    if (this->type == PICTURE)
        return ("setAscii");
    else if (this->type == SPEAK)
        return ("speak_es");
    else
        return ("");
}

Toy::Error& Toy::getLastError()
{
    if (!this->error.type)
        this->error.type = error.UNKNOWN;
    return (this->error);
}