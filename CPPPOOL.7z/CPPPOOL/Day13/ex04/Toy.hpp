/*
** EPITECH PROJECT, 2021
** day 13 ex 02
** File description:
** day 13 ex 02
*/

#ifndef TOY_HPP
#define TOY_HPP

#include <string>
#include "Picture.hpp"


class Toy
{
public :
    typedef enum ToyType
    {
        BASIC_TOY,
        ALIEN,
        BUZZ,
        WOODY
    } ToyType;

    Toy();
    Toy(ToyType type, std::string const &name, std::string filename);
    Toy(const Toy &toy);
    ~Toy();
    Toy& operator=(Toy const &toy);
    ToyType getType() const;
    std::string getName() const;
    void setName(std::string name);
    bool setAscii(std::string filename);
    std::string getAscii() const;
    virtual bool speak(std::string const statement) const;
    Toy& operator <<(std::string const statement);

private :
    ToyType type;
    std::string name;
    Picture picture;
};

std::ostream& operator <<(std::ostream& out, Toy const &toy);

#endif