#include <iostream>
#include <memory>
#include "Toy.hpp"
#include "Buzz.hpp"
#include "Woody.hpp"

int main ()
{
    Toy a(Toy::BASIC_TOY, "REX", "rex.txt");

    std::cout << a;
    a << "\\o/";
    std::cout << a;
    return 0;
}