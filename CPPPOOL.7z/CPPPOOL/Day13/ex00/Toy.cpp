/*
** EPITECH PROJECT, 2021
** day 13 ex 00
** File description:
** day 13 ex 00
*/

#include "Toy.hpp"

Toy::Toy() 
{
    this->type = BASIC_TOY;
    this->name = "toy";
    this->picture = Picture();
}

Toy::Toy(ToyType type, std::string name, std::string filename)
{
    this->type = type;
    this->name = name;
    this->picture = Picture(filename);
}

Toy::ToyType Toy::getType() const
{
    return (this->type);
}

std::string Toy::getName() const
{
    return (this->name);
}

void Toy::setName(std::string name)
{
    this->name = name;
}

bool Toy::setAscii(std::string filename)
{
    return (this->picture.getPictureFromFile(filename));
}

std::string Toy::getAscii() const
{
    return (this->picture.data);
}