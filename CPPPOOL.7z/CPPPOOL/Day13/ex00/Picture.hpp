/*
** EPITECH PROJECT, 2021
** day 13 ex 00
** File description:
** day 13 ex 00
*/

#ifndef PICTURE_HPP
#define PICTURE_HPP

#include "string"

class Picture
{
public :
    std::string data;
    Picture();
    Picture(const std::string &file);
    bool getPictureFromFile(const std::string &file);
};

#endif