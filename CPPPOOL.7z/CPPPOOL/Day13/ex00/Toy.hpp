/*
** EPITECH PROJECT, 2021
** day 13 ex 00
** File description:
** day 13 ex 00
*/

#ifndef TOY_HPP
#define TOY_HPP

#include <string>
#include "Picture.hpp"


class Toy
{
public :
    typedef enum ToyType
    {
        BASIC_TOY,
        ALIEN
    } ToyType;

    Toy();
    Toy(ToyType type, std::string name, std::string filename);
    ToyType getType() const;
    std::string getName() const;
    void setName(std::string name);
    bool setAscii(std::string filename);
    std::string getAscii() const;

private :
    ToyType type;
    std::string name;
    Picture picture;
};

#endif