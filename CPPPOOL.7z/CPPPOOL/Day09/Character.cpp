/*
** EPITECH PROJECT, 2021
** day 09 ex 01
** File description:
** day 09 ex 01
*/

#include <iostream>
#include "Character.hpp"

Character::Character(const std::string &name, int level)
{
    this->name = name;
    this->level = level;
    this->Pv = 100;
    this->Power = 100;
    this->Class = "Character";
    this->Race = "Human";
    this->Stamina = 5;
    this->Spirit = 5;
    this->Agility = 5;
    this->Strength = 5;
    this->Intelligence = 5;
    this->Range = CLOSE;
    std::cout << this->name << " Created" << std::endl;
}

const std::string &Character::getName() const
{
    return (this->name);
}

int Character::getLvl() const
{
    return(this->level);
}


int Character::getPv() const
{
    return (this->Pv);
}


int Character::getPower() const
{
    return (this->Power);
}

int Character::getIntelligence() const
{
    return (this->Intelligence);
}

int Character::getStrength() const 
{
    return (this->Strength);
}

int Character::getAgility() const
{
    return (this->Agility);
}

int Character::getSpirit() const
{
    return (this->Spirit);
}

int Character::getStamina() const
{
    return (this->Stamina);
}

std::string Character::getRace() const
{
    return (this->Race);
}

std::string Character::getClass() const
{
    return (this->Class);
}

void Character::setName(std::string const name)
{
    this->name = name;
}

void Character::setLvl(int const level)
{
    this->level = level;
}

void Character::setPv(int const pv)
{
    if (pv >= 100)
        this->Pv = 100;
    else if (pv <= 0)
        this->Pv = 0;
    else
        this->Pv = pv;
}

void Character::setPower(int const power)
{
    if (power >= 100)
        this->Power = 100;
    else
        this->Power = power;
}

void Character::setIntelligence(int const intel)
{
    this->Intelligence = intel;
}

void Character::setStrength(int const strength)
{
    this->Strength = strength;
}

void Character::setAgility(int const agility)
{
    this->Agility = agility;
}

void Character::setSpirit(int const spirit)
{
    this->Spirit = spirit;
}

void Character::setClass(std::string const _class)
{
    this->Class = _class;
}

void Character::setRace(std::string const race)
{
    this->Race = race;
}

void Character::setStamina(int const stamina)
{
    this->Stamina = stamina;
}

int Character::CloseAttack()
{
    if (this->Range != RANGE && (this->Power - 10) >= 0) {
        this->setPower(this->Power - 10);
        std::cout << this->name << " strikes with a wooden stick" << std::endl;
        return (10 + this->Strength);
    }
    else
        return (0);
}

void Character::Heal()
{
    this->setPv(this->Pv + 50);
    std::cout << this->name << " takes a potion" << std::endl;
}

int Character::RangeAttack()
{
    if (this->Power - 10 >= 0 && this->Range != CLOSE) {
        this->setPower(this->Power - 10);
        std::cout << this->name << " tosses a stone" << std::endl;
        return (5 + this->Strength);
    }
    else
        return (0);    
}

void Character::RestorePower()
{
    this->setPower(this->Power + 100);
    std::cout << this->name << " eats" << std::endl;
}

void Character::TakeDamage(int damage)
{
    this->setPv(this->Pv - damage);
    if (this->Pv > 0) {
        std::cout << this->name << " takes " << damage << " damage" << std::endl;
    } else
        std::cout << this->name << " out of combat" << std::endl;
}