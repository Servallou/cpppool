/*
** EPITECH PROJECT, 2021
** day 09 ex 03
** File description:
** day 09 ex 03
*/

#ifndef _MAGE_
#define _MAGE_

#include "Character.hpp"

class Mage : public virtual Character
{
public:
    Mage(const std::string &name, int level);
    int CloseAttack();
    int RangeAttack();
    void RestorePower();
};

#endif