/*
** EPITECH PROJECT, 2021
** day 09 ex 03
** File description:
** day 09 ex 03
*/

#ifndef _PRIEST_
#define _PRIEST_

#include "Mage.hpp"

class Priest : public Mage
{
public:
    Priest(const std::string &name, int level);
    int CloseAttack();
    void Heal();
};

#endif