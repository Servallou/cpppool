#include <iostream>
#include "Warrior.hpp"
#include "Character.hpp"
#include "Priest.hpp"
#include "Mage.hpp"
#include "Paladin.hpp"
#include "Hunter.hpp"

int main ()
{
    Character c("poney", 42) ;
    int damage = 0;

    // character
    c.TakeDamage(50);
    c.Heal();
    c.RestorePower();
    c.Range = Character::RANGE;
    damage = c.RangeAttack();
    std::cout << damage << std::endl;
    c.Range = Character::CLOSE;
    damage = c.CloseAttack();
    std::cout << damage << std::endl;
    c.TakeDamage(200);
    c.TakeDamage(200);

    std::cout << "\n\n";
    // warrior
    Warrior w("Thor", 76);
    damage = w.RangeAttack();
    std::cout << damage << std::endl;
    w.Range = Character::RANGE;
    damage = w.RangeAttack();
    std::cout << damage << std::endl;
    w.Heal();
    w.RestorePower();
    std::cout << w.CloseAttack() << std::endl;
    w.Range = Character::CLOSE;
    std::cout << w.CloseAttack() << std::endl;

    std::cout << "\n\n";
    // mage
    Mage m("Fluffy", 65);
    std::cout << m.CloseAttack() << std::endl;
    std::cout << m.RangeAttack() << std::endl;
    //w.Range = Character::RANGE;
    std::cout << m.CloseAttack() << std::endl;
    std::cout << m.RangeAttack() << std::endl;
    m.RestorePower();
    m.Heal();

    std::cout << "\n\n";
    // priest
    Priest p("Jean", 80);
    std::cout << p.CloseAttack() << std::endl;
    std::cout << p.RangeAttack() << std::endl;
    std::cout << p.CloseAttack() << std::endl;
    p.Heal();
    p.RestorePower();

    std::cout << "\n\n";
    Paladin theo("theo", 99);
    std::cout << theo.CloseAttack() << std::endl;
    theo.Heal();
    std::cout << theo.RangeAttack() << std::endl;
    theo.RestorePower();
    std::cout << theo.Intercept() << std::endl;

    std::cout << "\n\n";
    Hunter h("leonidas", 99);
    std::cout << h.CloseAttack() << std::endl;
    h.Heal();
    std::cout << h.RangeAttack() << std::endl;
    h.RestorePower();
    h.getPower();
}
