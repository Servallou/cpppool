/*
** EPITECH PROJECT, 2021
** day 09 ex 03
** File description:
** day 09 ex 03
*/

#include <iostream>
#include "Mage.hpp"

Mage::Mage(const std::string &name, int level) : Character(name, level)
{
    this->setClass("Mage");
    this->setRace("Gnome");
    this->setStrength(6);
    this->setStamina(6);
    this->setIntelligence(12);
    this->setSpirit(11);
    this->setAgility(7);
    std::cout << this->name << " teleported" << std::endl;
}

int Mage::CloseAttack()
{
    if (this->Range != RANGE && (this->Power - 10) >= 0) {
        this->setPower(this->Power - 10);
        std::cout << this->name << " blinks" << std::endl;
        this->Range = RANGE;
        return (0);
    }
    else
        return (0);
}

int Mage::RangeAttack()
{
    if (this->Power - 25 >= 0) {
        this->setPower(this->Power - 25);
        std::cout << this->name << " launches a fire ball" << std::endl;
        return (this->Spirit + 20);
    }
    else
        return (0);    
}

void Mage::RestorePower()
{
    this->setPower(this->Power + 50 + this->Intelligence);
    std::cout << this->name << " takes a mana potion" << std::endl;
}