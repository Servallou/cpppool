/*
** EPITECH PROJECT, 2021
** day 09 ex 04
** File description:
** day 09 ex 04
*/

#ifndef _PALADIN_
#define _PALADIN_

#include "Priest.hpp"
#include "Warrior.hpp"

class Paladin : public Warrior, public Priest
{
public :
    Paladin(std::string const &name, int level);
    int CloseAttack();
    int RangeAttack();
    void RestorePower();
    void Heal();
    int Intercept();
};

#endif