/*
** EPITECH PROJECT, 2021
** day 09 ex 02
** File description:
** day 09 ex 02
*/

#ifndef _WARRIOR_
#define _WARRIOR_

#include "Character.hpp"

class Warrior : public virtual Character
{
protected :
    const std::string weaponName;
public:
    Warrior(const std::string &name, int level);
    Warrior(const std::string &name, int level, std::string const &weaponName);
    int CloseAttack();
    int RangeAttack();
};

#endif