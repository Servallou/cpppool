/*
** EPITECH PROJECT, 2021
** day 09 ex 00
** File description:
** day09 ex 00
*/

#ifndef _EX00_
#define _EX00_

typedef struct cthulhu_s
{
    int m_power;
    char *m_name;
} cthulhu_t;

typedef struct koala_s
{
    cthulhu_t m_parent;
    char m_is_a_legend;
} koala_t;

#endif
