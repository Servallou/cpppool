/*
** EPITECH PROJECT, 2021
** day 09 ex 03
** File description:
** day 09 ex 03
*/

#include <iostream>
#include "Priest.hpp"

Priest::Priest(const std::string &name, int level) : Character(name, level), Mage(name, level)
{
    this->setClass("Priest");
    this->setRace("Orc");
    this->setStrength(4);
    this->setStamina(4);
    this->setIntelligence(42);
    this->setSpirit(21);
    this->setAgility(2);
    std::cout << this->name << " enters in the order" << std::endl;
}

int Priest::CloseAttack()
{
    if (this->Range == RANGE || (this->Power - 10) < 0)
        return (0);
    this->setPower(this->Power - 10);
    std::cout << this->name << " uses a spirit explosion" << std::endl;
    this->Range = RANGE;
    return (10 + this->Spirit);
}

void Priest::Heal()
{
    if (this->Power - 10 > 0) {
        this->setPower(this->Power - 10);
        this->setPv(this->Pv + 70);
        std::cout << this->name << " casts a little heal spell" << std::endl;
    }
}