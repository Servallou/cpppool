/*
** EPITECH PROJECT, 2021
** day 09 ex 05
** File description:
** day 09 ex 05
*/

#include <iostream>
#include "Hunter.hpp"

Hunter::Hunter(std::string const &name, int level) : Character(name, level), Warrior(name, level, "sword")
{
    this->setClass("Hunter");
    this->setRace("Elf");
    this->setStrength(9);
    this->setStamina(9);
    this->setIntelligence(5);
    this->setSpirit(6);
    this->setAgility(25);
    std::cout << this->name << " is born from a tree" << std::endl;
};

int Hunter::CloseAttack()
{
    return (Warrior::CloseAttack());
}

void Hunter::Heal()
{
    Warrior::Heal();
}

int Hunter::RangeAttack()
{
    if (this->Power >= 25)
        {
            std::cout << this->name << " uses his bow" << std::endl;
            this->setPower(this->Power - 25);
            return (20 + this->Agility);
        }
    else
        return (0);
}

void Hunter::RestorePower()
{
    this->setPower(this->Power + 100);
    std::cout << this->name << " meditates" << std::endl;
}

int Hunter::getLvl() const
{
    return (Warrior::getLvl());
}

int Hunter::getPv() const 
{
    return (Warrior::getPv());
}

int Hunter::getPower() const
{
    return (Warrior::getPower());
}

int Hunter::getStamina() const
{
    return (Warrior::getStamina());
}

int Hunter::getIntelligence() const
{
    return (Warrior::getIntelligence());
}

int Hunter::getStrength() const
{
    return (Warrior::getStrength());
}

int Hunter::getAgility() const
{
    return (Warrior::getAgility());
}

int Hunter::getSpirit() const
{
    return (Warrior::getSpirit());
}

std::string Hunter::getRace() const
{
    return (Warrior::getRace());
}

std::string Hunter::getClass() const
{
    return (Warrior::getClass());
}

void Hunter::setName(std::string const name)
{
    Warrior::setName(name);
}

void Hunter::setLvl(int const level)
{
    Warrior::setLvl(level);
}

void Hunter::setPv(int const pv)
{
    Warrior::setPv(pv);
}

void Hunter::setPower(int const power)
{
    Warrior::setPower(power);
}

void Hunter::setStamina(int const stamina)
{
    Warrior::setStamina(stamina);
}

void Hunter::setIntelligence(int const intel)
{
    Warrior::setIntelligence(intel);
}

void Hunter::setStrength(int const strength)
{
    Warrior::setStrength(strength);
}

void Hunter::setAgility(int const agility)
{
    Warrior::setAgility(agility);
}

void Hunter::setSpirit(int const spirit)
{
    Warrior::setSpirit(spirit);
}

void Hunter::setClass(std::string const _class)
{
    Warrior::setClass(_class);
}

void Hunter::setRace(std::string const race)
{
    Warrior::setRace(race);
}