/*
** EPITECH PROJECT, 2021
** day 09 ex 05
** File description:
** day 09 ex 05
*/

#ifndef _HUNTER_
#define _HUNTER_

#include "Warrior.hpp"

class Hunter : protected Warrior
{
public:
    Hunter(const std::string &name, int level);
    int CloseAttack();
    int RangeAttack();
    void RestorePower();
    void Heal();
    virtual int getLvl() const;
    virtual int getPv() const;
    virtual int getPower() const;
    virtual int getStamina() const;
    virtual int getIntelligence() const;
    virtual int getStrength() const;
    virtual int getAgility() const;
    virtual int getSpirit() const;
    virtual std::string getRace() const;
    virtual std::string getClass() const;
    virtual void setName(std::string const name);
    virtual void setLvl(int const level);
    virtual void setPv(int const pv);
    virtual void setPower(int const power);
    virtual void setStamina(int const stamina);
    virtual void setIntelligence(int const intel);
    virtual void setStrength(int const strength);
    virtual void setAgility(int const agility);
    virtual void setSpirit(int const spirit);
    virtual void setClass(std::string const _class);
    virtual void setRace(std::string const race);
};

#endif