/*
** EPITECH PROJECT, 2021
** day 09 ex 01
** File description:
** day 09 ex 01
*/

#ifndef _CHARACTER_
#define _CHARACTER_

#include <string>

class Character
{
protected :
    std::string name;
    int level;
    std::string Class;
    std::string Race;
    int Strength;
    int Stamina;
    int Intelligence;
    int Spirit;
    int Agility;
    int Pv;
    int Power;
public  :
    typedef enum AttackRange {
        CLOSE,
        RANGE
    } AttackRange;

    AttackRange Range;

    Character(const std::string &name, int level);
    const std::string &getName() const;
    int getLvl() const;
    int getPv() const;
    int getPower() const;
    int getStamina() const;
    int getIntelligence() const;
    int getStrength() const;
    int getAgility() const;
    int getSpirit() const;
    std::string getRace() const;
    std::string getClass() const;
    void setName(std::string const name);
    void setLvl(int const level);
    void setPv(int const pv);
    void setPower(int const power);
    void setStamina(int const stamina);
    void setIntelligence(int const intel);
    void setStrength(int const strength);
    void setAgility(int const agility);
    void setSpirit(int const spirit);
    void setClass(std::string const _class);
    void setRace(std::string const race);
    int CloseAttack();
    void Heal();
    int RangeAttack();
    void RestorePower();
    void TakeDamage(int damage);  
};

#endif