/*
** EPITECH PROJECT, 2021
** day 09 ex 02
** File description:
** day 09 ex 02
*/

#include <iostream>
#include "Warrior.hpp"

Warrior::Warrior(const std::string &name, int level, const std::string &weapon) : Character(name, level), weaponName(weapon)
{
    this->setClass("Warrior");
    this->setRace("Dwar");
    this->setStrength(12);
    this->setStamina(12);
    this->setIntelligence(6);
    this->setAgility(7);
    std::cout << "I'm " << this->name;
    std::cout << " KKKKKKKKKKRRRRRRRRRRRRRREEEEEEEEOOOOOOORRRRGGGGGGG" << std::endl;
}

Warrior::Warrior(const std::string &name, int level) : Character(name, level), weaponName("hammer")
{
    this->setClass("Warrior");
    this->setRace("Dwarf");
    this->setStrength(12);
    this->setStamina(12);
    this->setIntelligence(6);
    this->setAgility(7);
    std::cout << "I'm " << this->name;
    std::cout << " KKKKKKKKKKRRRRRRRRRRRRRREEEEEEEEOOOOOOORRRRGGGGGGG" << std::endl;
}

int Warrior::CloseAttack()
{
    if (this->Range != RANGE && (this->Power - 30) >= 0) {
        this->setPower(this->Power - 30);
        std::cout << this->name << " strikes with his ";
        std::cout << this->weaponName << std::endl;
        return (20 + this->Strength);
    } else
        return (0);    
}

int Warrior::RangeAttack()
{
    if (this->Range != CLOSE && (this->Power - 10) >= 0) {
        this->setPower(this->Power - 10);
        std::cout << this->name << " intercepts" << std::endl;
        this->Range = CLOSE;
        return (0);
    } else
    return (0);
}