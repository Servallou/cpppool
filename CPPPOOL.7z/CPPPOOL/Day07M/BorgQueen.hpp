/*
** EPITECH PROJECT, 2021
** day 07 m ex 4 cpp
** File description:
** day 07 m ex 4 cpp
*/

#ifndef _BORGQUEEN_
#define _BORGQUEEN_

namespace Borg
{
    class BorgQueen;
};

#include <iostream>
#include "Federation.hpp"
#include "Borg.hpp"

namespace Borg
{
        class BorgQueen
        {
        public :
            BorgQueen();
            void (Borg::Ship::*firePtr)(Federation::Starfleet::Ship *target);
            void fire(Borg::Ship *ship, Federation::Starfleet::Ship *target);
            bool (Borg::Ship::*movePtr)(Destination dest);
            bool move(Borg::Ship *ship, Destination dest);
            void (Borg::Ship::*destroyPtr)(Federation::Ship *target);
            void destroy(Borg::Ship *ship, Federation::Ship *target);
        };
}

#endif