/*
** EPITECH PROJECT, 2021
** day 07 m ex 1 cpp
** File description:
** day 07 m ex 01 cpp
*/

#ifndef _BORG_
#define _BORG_

namespace Borg
{
    class Ship;
};

#include "WarpSystem.hpp"
#include "Destination.hpp"
#include "Federation.hpp"

namespace Borg
{
    class Ship
    {
    private :
        int _length;
        int _side;
        short _maxWarp;
        WarpSystem::Core *Core;
        Destination _location;
        Destination _home;
        int _shield;
        int _weaponFrequency;
        short _repair;
    public :
        Ship(int weaponFrequency = 20, short repair = 3);
        void setupCore(WarpSystem::Core *core);
        void checkCore();
        bool move(int warp, Destination d);
        bool move(int warp);
        bool move(Destination d);
        bool move();
        int getShield();
        void setShield(int shield);
        int getWeaponFrequency();
        void setWeaponFrequency(int frenquency);
        short getRepair();
        void setRepair(short repair);
        void fire(Federation::Starfleet::Ship *target);
        void fire(Federation::Ship *target);
        void repair();
    };
}

#endif
