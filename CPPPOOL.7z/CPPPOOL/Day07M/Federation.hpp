/*
** EPITECH PROJECT, 2021
** day 07 m ex 0 cpp
** File description:
** day 07 m cpp ex 0
*/

#ifndef _FEDERATION_
#define _FEDERATION_

namespace Federation
{
    namespace Starfleet
    {
        class Ship;
        class Captain;
        class Ensign;
    };
    
    class Ship;
};

#include <string>
#include "WarpSystem.hpp"
#include "Destination.hpp"
#include "Borg.hpp"

namespace Federation
{
    namespace Starfleet
    {
        class Captain
        {
        private :
            std::string _name;
            int _age;
        public :
            Captain(std::string _name);
            std::string getName();
            int getAge();
            void setAge(int age);
        };

        class Ensign
        {
        private :
            std::string _name;
        public :
            Ensign(std::string name);
        };

        class Ship
        {
        private :
            int _length;
            int _width;
            std::string _name;
            short _maxWarp;
            WarpSystem::Core *Core;
            Destination _location;
            Destination _home;
            int _shield;
            int _photonTorpedo;
            std::string _capitain;
        public :
            Ship(int length, int width, std::string name, short maxWarp, int torpedo = 0);
            Ship();
            void setupCore(WarpSystem::Core *core);
            void checkCore();
            void promote(Federation::Starfleet::Captain *captain);
            bool move(int warp, Destination d);
            bool move(int warp);
            bool move(Destination d);
            bool move();
            int getShield();
            void setShield(int shield);
            int getTorpedo();
            void setTorpedo(int torpedo);
            void fire(Borg::Ship *target);
            void fire(int torpedoes, Borg::Ship *target);
        };
    }

    class Ship
    {
    private :
        int _length;
        int _width;
        std::string _name;
        short _maxWarp;
        WarpSystem::Core *Core;
        Destination _location;
        Destination _home;
    public :
        Ship(int length, int width, std::string name);
        void setupCore(WarpSystem::Core *core);
        void checkCore();
        bool move(int warp, Destination d);
        bool move(int warp);
        bool move(Destination d);
        bool move();
        WarpSystem::Core *getCore();
    };
}

#endif
