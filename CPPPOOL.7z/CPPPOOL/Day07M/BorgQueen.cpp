/*
** EPITECH PROJECT, 2021
** day 07 m ex 4 cpp
** File description:
** day 07 m ex 4 cpp
*/

#include "BorgQueen.hpp"

Borg::BorgQueen::BorgQueen()
{
    this->firePtr = &Borg::Ship::fire;
    this->movePtr = &Borg::Ship::move;
    this->destroyPtr = &Borg::Ship::fire;
}

void Borg::BorgQueen::fire(Borg::Ship *ship, Federation::Starfleet::Ship *target)
{
    (ship->*firePtr)(target);
}

bool Borg::BorgQueen::move(Borg::Ship *ship, Destination dest)
{
    return ((ship->*movePtr)(dest));
}

void Borg::BorgQueen::destroy(Borg::Ship *ship, Federation::Ship *target)
{
    (ship->*destroyPtr)(target);
}