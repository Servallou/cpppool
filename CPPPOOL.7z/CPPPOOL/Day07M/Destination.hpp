#ifndef _DESTINATION_
#define _DESTINATION_

enum Destination
{
    EARTH,
    VULCAN,
    ROMULUS,
    REMUS,
    UNICOMPLEX,
    JUPITER,
    BABEL
};

#endif
