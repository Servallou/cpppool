/*
** EPITECH PROJECT, 2021
** day 07 m ex 1 cpp
** File description:
** day 07 m ex1 cpp
*/

#include <iostream>
#include "Borg.hpp"

Borg::Ship::Ship(int weaponFrequency, short repair)
{
    this->_home = UNICOMPLEX;
    this->_location = this->_home;
    this->_shield = 100;
    this->_weaponFrequency = weaponFrequency;
    this->_repair = repair;
    std::cout << "We are the Borgs. Lower your shields and surrender";
    std::cout << " yourselves unconditionally." << std::endl;
    std::cout << "Your biological characteristics and technologies";
    std::cout << " will be assimilated." << std::endl;
    std::cout << "Resistance is futile." << std::endl;
}

void Borg::Ship::setupCore(WarpSystem::Core *Core)
{
    this->Core = Core;
}

void Borg::Ship::checkCore()
{
    if (this->Core->checkReactor()->isStable() == true) {
        std::cout << "Everything is in order." << std::endl;
    }
    else {
        std::cout << "Critical failure imminent." << std::endl;
    }
}

bool Borg::Ship::move(int warp, Destination d)
{
    if (warp <= this->_maxWarp && d != this->_location) {
        if (this->Core->checkReactor()->isStable() == true) {
            this->_location = d;
            return (true);
        }
        else
            return (false);
    }
    else {
        return (false);
    }
}

bool Borg::Ship::move(int warp)
{
    if (warp <= this->_maxWarp) {
        this->_location = this->_home;
        return (true);
    }
    else
        return (false);
}

bool Borg::Ship::move(Destination d)
{
    if (d != this->_location) {
        this->_location = d;
        return (true);
    }
    else
        return (false);
}

bool Borg::Ship::move()
{
    this->_location = this->_home;
    return (true);
}

int Borg::Ship::getShield()
{
    return (this->_shield);
}

void Borg::Ship::setShield(int shield)
{
    this->_shield = shield;
}

int Borg::Ship::getWeaponFrequency()
{
    return (this->_weaponFrequency);
}

void Borg::Ship::setWeaponFrequency(int frequency)
{
    this->_weaponFrequency = frequency;
}

short Borg::Ship::getRepair()
{
    return (this->_repair);
}

void Borg::Ship::setRepair(short repair)
{
    this->_repair = repair;
}

void Borg::Ship::fire(Federation::Starfleet::Ship *target)
{
    int shield = target->getShield();

    target->setShield(shield - this->_weaponFrequency);
    std::cout << "Firing on target with " << this->_weaponFrequency;
    std::cout << "GW frequency." << std::endl;
}

void Borg::Ship::fire(Federation::Ship *target)
{
    WarpSystem::Core *Core = target->getCore();
    WarpSystem::QuantumReactor *reactor = Core->checkReactor();
    
    reactor->setStability(false);
    std::cout << "Firing on target with " << this->_weaponFrequency;
    std::cout << "GW frequency." << std::endl;
}

void Borg::Ship::repair()
{
    if (this->_repair != 0) {
        this->_repair = this->_repair - 1;
        this->_shield = 100;
        std::cout << "Begin shield re-initialisation... Done.";
        std::cout << " Awaiting further instructions." << std::endl;
    } else
        std::cout << "Energy cells depleted, shield weakening." << std::endl;
}