/*
** EPITECH PROJECT, 2021
** day 07 m ex 0 cpp
** File description:
** day 07 ex 0 cpp
*/

#ifndef _WARPSYSTEM_
#define _WARPSYSTEM_

namespace WarpSystem
{
    class QuantumReactor
    {
    private :
        bool _stability;
    public :
        QuantumReactor();
        bool isStable();
        void setStability(bool stability);
    };

    class Core
    {
    private :
        QuantumReactor *_coreReactor;
    public :
        Core(QuantumReactor *Reactor);
        QuantumReactor *checkReactor();
    };
}

#endif
