/*
** EPITECH PROJECT, 2021
** day 07 m ex 4 cpp
** File description:
** day 07 m ex 4 cpp
*/

#ifndef _ADMIRAL_
#define _ADMIRAL_

namespace Federation
{
    namespace Starfleet
    {
        class Admiral;
    };
};

#include <iostream>
#include "Federation.hpp"
#include "Borg.hpp"

namespace Federation
{
    namespace Starfleet
    {
        class Admiral
        {
        private :
            std::string _name;
        public :
            Admiral(std::string name);
            void (Federation::Starfleet::Ship::*firePtr)(Borg::Ship *target);
            void fire(Federation::Starfleet::Ship *ship, Borg::Ship *target);
            bool (Federation::Starfleet::Ship::*movePtr)(Destination dest);
            bool move(Federation::Starfleet::Ship *ship, Destination dest);
        };
    }
}

#endif