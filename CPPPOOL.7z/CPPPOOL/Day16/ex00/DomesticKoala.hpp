/*
** EPITECH PROJECT, 2021
** day 16 ex00
** File description:
** day 16 ex00
*/

#ifndef DOMESTICKOALA_HPP
#define DOMESTICKOALA_HPP

//#include "KoalaAction.hpp"
#include <vector>
#include <string>
#include <iostream>

class KoalaAction {
public :
    KoalaAction() {}
    ~KoalaAction() {}

    void goTo(const std::string &str) {
        std::cout << "go to :" <<  str << std::endl;
    }
    void sleep(const std::string &str) {
        std::cout << "sleep :" << str << std::endl;
    }
    void eat(const std::string &str) {
        std::cout << "eat :" << str << std::endl;
    }
    void reproduce(const std::string &str) {
        std::cout << "reproduce :" << str << std::endl;
    }
private :
};

class DomesticKoala
{
    public :
        DomesticKoala(KoalaAction &);
        ~DomesticKoala();
        DomesticKoala(const DomesticKoala &);
        DomesticKoala &operator=(const DomesticKoala &);
        using methodPointer_t = void (KoalaAction::*)(const std::string &);
        const std::vector<methodPointer_t> *getAction() const;
        void learnAction(unsigned char command, methodPointer_t action);
        void unlearnAction(unsigned char command);
        void doAction(unsigned char command, const std::string &param);
        void setKoalaAction(KoalaAction &);
    private :
        KoalaAction action;
        std::vector<methodPointer_t> vec;
};

#endif