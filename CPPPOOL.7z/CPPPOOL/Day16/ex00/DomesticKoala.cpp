/*
** EPITECH PROJECT, 2021
** day 16 ex00
** File description:
** day 16 ex00
*/

#include "DomesticKoala.hpp"

DomesticKoala::DomesticKoala(KoalaAction &action) : vec(256)
{
    this->action = action;
}

DomesticKoala::~DomesticKoala()
{

}

DomesticKoala::DomesticKoala(const DomesticKoala &cp)
{
    this->action = cp.action;
    this->vec = cp.vec;
}

DomesticKoala &DomesticKoala::operator=(const DomesticKoala &cp)
{
    if (this != &cp) {
        this->action = cp.action;
        if (!this->vec.empty())
            this->vec.clear();
        for (unsigned int i = 0; i < cp.vec.size(); i++)
            this->vec.push_back(cp.vec[i]);
    }
    return (*this);
}

const std::vector<DomesticKoala::methodPointer_t> *DomesticKoala::getAction() const
{
    return (&this->vec);
}

void DomesticKoala::learnAction(unsigned char command, methodPointer_t action) 
{
    this->vec[command] = action;
}

void DomesticKoala::unlearnAction(unsigned char command)
{
    this->vec[command] = NULL;
}

void DomesticKoala::doAction(unsigned char command, const std::string &param)
{
    methodPointer_t call = this->vec[command];
    if (call)
        (this->action.*call)(param);
}

void DomesticKoala::setKoalaAction(KoalaAction &action)
{
    this->action = action;
}